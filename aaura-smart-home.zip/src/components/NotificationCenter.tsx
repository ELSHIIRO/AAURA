import React from "react";
import { NotificationItem } from "../types";

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onClearNotif: (id: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
  onClearNotif,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex justify-end animate-[fadeIn_0.2s_ease-out]">
      <div className="w-full max-w-md h-full bg-[#f7fafa] shadow-2xl border-l border-white/40 flex flex-col p-6 overflow-hidden">
        <div className="flex items-center justify-between pb-4 border-b border-white/60">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00666b]">
              notifications
            </span>
            <h3 className="font-bold text-xl text-[#181c1c]">Notificaciones</h3>
          </div>
          <div className="flex items-center gap-2">
            {notifications.some((n) => !n.read) && (
              <button
                onClick={onMarkAllRead}
                className="text-xs text-[#00666b] font-bold hover:underline cursor-pointer"
              >
                Marcar leídas
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 text-[#3e4949] hover:bg-black/5 rounded-full transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-2xl">close</span>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto py-4 flex flex-col gap-3">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center text-[#3e4949]">
              <span className="material-symbols-outlined text-5xl mb-2 opacity-40">
                notifications_off
              </span>
              <p className="text-sm font-medium">No tienes notificaciones pendientes.</p>
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                className={`p-4 rounded-2xl glass-card relative border transition-all ${
                  !notif.read ? "border-[#00666b]/40 bg-[#f4ffff]" : "border-white/50"
                }`}
              >
                <div className="flex justify-between items-start mb-1">
                  <h4 className="font-bold text-sm text-[#181c1c]">
                    {notif.title}
                  </h4>
                  <span className="text-[10px] text-[#3e4949] font-medium">
                    {notif.time}
                  </span>
                </div>
                <p className="text-xs text-[#3e4949] leading-relaxed pr-6">
                  {notif.message}
                </p>
                <button
                  onClick={() => onClearNotif(notif.id)}
                  className="absolute bottom-3 right-3 text-[#3e4949] hover:text-[#ba1a1a] transition-colors p-1 cursor-pointer"
                  title="Eliminar"
                >
                  <span className="material-symbols-outlined text-base">
                    delete
                  </span>
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
