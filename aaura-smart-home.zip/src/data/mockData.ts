import {
  Scene,
  SonosDevice,
  NestThermostatDevice,
  PuraDiffuserDevice,
  HueLightingDevice,
  SmartDeviceItem,
  Routine,
  HistoryLog,
  NotificationItem,
} from "../types";

export const initialScenes: Scene[] = [
  {
    id: "scene-rainy-day",
    title: "Día Lluvioso",
    description:
      "Ambiente relajante que simula un día lluvioso con sonidos envolventes, aroma fresco y luces tenues.",
    imageUrl:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDY6qRrXqmdC5Z4dxpQI_3OoqZWc-S-Kf9JZSA1Hp9nUHs1SeEkoH4XfNXDVJnK4PNG-DbNP6a8kKaYzD4PpfO7_eP3Dksy0F_zlrC19VVuDDKzC4ecq3jZbS40syGsxoJm-aELsx-65sCLMpy9PTNoUozWQBjWPYCyzwud9rUoxKVwqSXHo4a45hXPgbcV-xdXMD8N4jQf2kPKLU9pLrXDC3ukJKB5CNFK0zgomta6paSEhCmwxZzx",
    isFavorite: true,
    category: "Sensorial",
    audio: {
      soundType: "rain",
      trackName: "Lluvia en ventana + truenos lejanos",
      volume: 40,
    },
    climate: {
      temperature: 22,
      humidity: 65,
      ventilation: "Ventilación suave",
    },
    aroma: {
      fragrance: "Petricor, musgo y ozono",
      intensity: 70,
    },
    lighting: {
      colorName: "Gris azulado",
      colorHex: "#5A7184",
      brightness: 30,
      colorTemp: "Frío",
    },
  },
  {
    id: "scene-sunset-beach",
    title: "Atardecer en la Playa",
    description:
      "Aroma a sal marina y jazmín con sonido suave de olas y luces doradas de atardecer.",
    imageUrl:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuCt8Ofl7aL4iXLMkljTbFWbvPdDLfvEBWEUrM_byVouAFjGYljH16hyvb5tmgG26WHfCwFpHKkxgMI6_395hFNlI7TQjLFESU8QEKfJvYxcgUZcklZcOLc-IaqhJjYGfgE_83mFmX6TfnGTzAU4y4-iPsRmvCvzSOFrQiN02g-vdWksUNIwWYgg2urXnhdtrX3894vhQSuN2mXI9mmQDcGrh947yLTeVd4hEDc43mrNjLl5rVfHzV-T",
    isFavorite: true,
    category: "Relajación",
    audio: {
      soundType: "waves",
      trackName: "Olas rítmicas en la orilla + brisa",
      volume: 50,
    },
    climate: {
      temperature: 24,
      humidity: 60,
      ventilation: "Brisa marina constante",
    },
    aroma: {
      fragrance: "Sal marina, floripondio y coco",
      intensity: 65,
    },
    lighting: {
      colorName: "Ámbar dorado",
      colorHex: "#E67E22",
      brightness: 50,
      colorTemp: "Cálido",
    },
  },
  {
    id: "scene-forest-dawn",
    title: "Bosque al Amanecer",
    description:
      "Atmósfera con notas de musgo, pino y bruma con murmullo suave de aves silvestres.",
    imageUrl:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDqC4rmCeY3hglSFg1h4OwHUixfzb9T1L22lb1hVV3RySJzCg60BvIyf3WR8MXk3YPI2ZQNFbaJVwawyWMSb-cBVZ4LM0dzfz4szCFiyOtj_D79dP7Pv74s5YNSuORh4U4aQcPTQBe0MbYmjZlv00MVhaiQAM9O1v6hOZNkpYdQQa6yIqF1CptGtXTQDUsom8TfoejuqRNN0IrpOi6Y_BqFRGrvpO3HE9kFpyrxc109_-XsXvQOXBb7",
    isFavorite: false,
    category: "Sensorial",
    audio: {
      soundType: "forest",
      trackName: "Canto de aves silvestres + viento en copas",
      volume: 35,
    },
    climate: {
      temperature: 20,
      humidity: 75,
      ventilation: "Brisa fresca de montaña",
    },
    aroma: {
      fragrance: "Eucalipto, musgo y pino fresco",
      intensity: 80,
    },
    lighting: {
      colorName: "Verde esmeralda ténue",
      colorHex: "#2ECC71",
      brightness: 35,
      colorTemp: "Templado",
    },
  },
  {
    id: "scene-winter-night",
    title: "Noche de Invierno",
    description:
      "Calidez acogedora de chimenea, aroma a madera ahumada y tonos cálidos tenues.",
    imageUrl:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAKbIe5LgyF7TZ1PXAElg5XOLSCVk_1_zo5VmE2E669k5uc3gDTRf3Ekp8FwJksYC78i1hQ0Dh3_l1yxzscMEtsBfuHVKgisxtC6wN2hGJySKyRqjrS-_kpvJGaNndqDYfgXIB6ywk9lxFgtZ5rEnc1TilkfePVciJSMBSWPBehjWCIeqbsHZ_5-o6HnWS3RmbdJkzB_o4SBhg6JlwNO6cpdVPwDydUlXlP1kV1bJCMh2wB59145fEg",
    isFavorite: true,
    category: "Noche",
    audio: {
      soundType: "fireplace",
      trackName: "Crujido de leña + viento invernal",
      volume: 45,
    },
    climate: {
      temperature: 23,
      humidity: 50,
      ventilation: "Calefacción radiante constante",
    },
    aroma: {
      fragrance: "Madera de cedro, vainilla y canela",
      intensity: 75,
    },
    lighting: {
      colorName: "Fuego tenue 2200K",
      colorHex: "#E74C3C",
      brightness: 25,
      colorTemp: "Cálido",
    },
  },
];

export const initialSonosDevice: SonosDevice = {
  id: "device-audio-sonos",
  name: "Audio",
  model: "Sonos Era 300",
  isPoweredOn: true,
  volume: 40,
  currentTrack: "Lluvia en ventana + truenos lejanos",
  bass: 2,
  treble: 1,
};

export const initialNestThermostat: NestThermostatDevice = {
  id: "device-climate-nest",
  name: "Clima",
  model: "Nest Thermostat",
  isPoweredOn: true,
  targetTemp: 22,
  indoorTemp: 22,
  humidity: 65,
  mode: "Eco",
};

export const initialPuraDiffuser: PuraDiffuserDevice = {
  id: "device-aroma-pura",
  name: "Aroma",
  model: "Pura Diffuser",
  isPoweredOn: true,
  intensity: 70,
  currentFragrance: "Petricor",
  availableFragrances: [
    "Petricor",
    "Jazmín y Sal Marina",
    "Lavanda Silvestre",
    "Eucalipto & Pino",
    "Vainilla Ahumada",
  ],
};

export const initialHueLighting: HueLightingDevice = {
  id: "device-lighting-hue",
  name: "Iluminación",
  model: "Philips Hue",
  isPoweredOn: true,
  brightness: 30,
  colorName: "Gris azulado",
  colorHex: "#5A7184",
  colorTemp: "Frío",
};

export const initialSmartDevices: SmartDeviceItem[] = [
  {
    id: "dev-plug-1",
    name: "Enchufe Inteligente - Sala",
    category: "Confort",
    status: "Encendido • 12W",
    isOnline: true,
    isPoweredOn: true,
    location: "Sala de Estar",
    icon: "power",
  },
  {
    id: "dev-shade-1",
    name: "Cortinas Motorizadas",
    category: "Confort",
    status: "Abiertas 40%",
    isOnline: true,
    isPoweredOn: true,
    location: "Habitación Principal",
    icon: "curtains",
  },
  {
    id: "dev-cam-1",
    name: "Cámara HD Exterior",
    category: "Seguridad",
    status: "Monitoreando • En vivo",
    isOnline: true,
    isPoweredOn: true,
    location: "Jardín Frontal",
    icon: "videocam",
  },
  {
    id: "dev-purifier-1",
    name: "Purificador de Aire Dyson",
    category: "Clima",
    status: "Calidad de aire: Excelente (AQI 12)",
    isOnline: true,
    isPoweredOn: true,
    location: "Estudio",
    icon: "airwave",
  },
];

export const initialRoutines: Routine[] = [
  {
    id: "rot-morning",
    title: "Buenos Días Sensoriales",
    description:
      "A las 07:00 AM activa aroma de eucalipto, iluminación tenue cálida y clima a 21°C.",
    schedule: "Todos los días a las 07:00 AM",
    icon: "wb_twilight",
    isActive: true,
    sceneId: "scene-forest-dawn",
    days: ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"],
  },
  {
    id: "rot-work",
    title: "Modo Enfoque Profundo",
    description:
      "Activa sonido de lluvia ambiental y luz blanca neutra al iniciar jornada laboral.",
    schedule: "Lun - Vie a las 09:00 AM",
    icon: "laptop_mac",
    isActive: true,
    sceneId: "scene-rainy-day",
    days: ["Lun", "Mar", "Mié", "Jue", "Vie"],
  },
  {
    id: "rot-sunset",
    title: "Desconexión de Atardecer",
    description:
      "Gradúa iluminación a tonos ámbar y activa difusión de lavanda al ponerse el sol.",
    schedule: "Diario al atardecer (~06:30 PM)",
    icon: "wb_sunny",
    isActive: false,
    sceneId: "scene-sunset-beach",
    days: ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"],
  },
  {
    id: "rot-night",
    title: "Descanso Nocturno",
    description:
      "Apaga luces principales, ajusta temperatura a 20°C y activa sonido de chimenea.",
    schedule: "Todos los días a las 11:00 PM",
    icon: "bedtime",
    isActive: true,
    sceneId: "scene-winter-night",
    days: ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"],
  },
];

export const initialHistoryLogs: HistoryLog[] = [
  {
    id: "log-1",
    timestamp: "Hace 10 minutos",
    title: "Escena Activada: Día Lluvioso",
    description: "Iniciada manualmente desde el panel principal.",
    category: "escena",
    icon: "auto_awesome",
  },
  {
    id: "log-2",
    timestamp: "Hace 45 minutos",
    title: "Ajuste de Temperatura Nest",
    description: "Temperatura objetivo modificada a 22°C por Alex.",
    category: "dispositivo",
    icon: "thermostat",
  },
  {
    id: "log-3",
    timestamp: "Hace 2 horas",
    title: "Creación de Escena por IA",
    description: 'Comando de voz procesado: "Recrea un día lluvioso de otoño".',
    category: "ia",
    icon: "mic",
  },
  {
    id: "log-4",
    timestamp: "Hace 5 horas",
    title: "Rutina Ejecutada: Buenos Días",
    description: "Activada automáticamente a las 07:00 AM.",
    category: "rutina",
    icon: "schedule",
  },
  {
    id: "log-5",
    timestamp: "Ayer a las 09:30 PM",
    title: "Cambio de Fragancia Pura",
    description: "Aroma cambiado a Petricor con intensidad 70%.",
    category: "dispositivo",
    icon: "air",
  },
];

export const initialNotifications: NotificationItem[] = [
  {
    id: "notif-1",
    title: "Escena Activa",
    message: "La escena 'Día Lluvioso' está en reproducción en la Sala.",
    time: "Ahora",
    type: "info",
    read: false,
  },
  {
    id: "notif-2",
    title: "Dispositivo Conectado",
    message: "Sonos Era 300 se ha sincronizado exitosamente con el puente AAURA.",
    time: "Hace 1 hora",
    type: "success",
    read: false,
  },
  {
    id: "notif-3",
    title: "Nivel de Aroma",
    message: "El cartucho 'Petricor' del difusor Pura está al 25% de capacidad.",
    time: "Hace 3 horas",
    type: "warning",
    read: true,
  },
];
