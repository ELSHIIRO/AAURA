import React from "react";

export const ProfileView: React.FC = () => {
  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto px-4 md:px-8 py-6 pb-32 text-left">
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-white/60 shadow-sm flex flex-col md:flex-row items-center gap-6">
        <img
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuArlVlAtvphSgOD7dSusdI5umrSyGPde4Yl24ewxbXsBkBrbQVgs4eT7xITAEUmrAO4xRwpb_buQgY6ev89nYdPRgBikjaE-WQqjv0Vo4XhMWPFygx8Ntyo9dYCpEMYX-lv3kO_TJkeQhaEAQyrDqIRivXBLBpHTHeLdC_g270RGUNqRbSFLqDVpw-Me9wIJ1DPHKdkHZdYaYvfPkj0T4PxsYFEWwu7P3ztkLwMuASJLzcKQQmuM3jj"
          alt="Alex Profile"
          className="w-24 h-24 rounded-full object-cover border-2 border-white shadow-md"
        />
        <div className="flex-1 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
            <h2 className="text-2xl font-bold text-[#181c1c]">Alex M.</h2>
            <span className="bg-[#00666b] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full">
              Propietario
            </span>
          </div>
          <p className="text-xs text-[#3e4949] mb-3">
            alex.home@aaura-smarthome.io • Casa Principal
          </p>
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
            <span className="text-xs font-semibold bg-white/60 px-3 py-1 rounded-full text-[#00666b]">
              4 Dispositivos Conectados
            </span>
            <span className="text-xs font-semibold bg-white/60 px-3 py-1 rounded-full text-[#00666b]">
              3 Escenas Favoritas
            </span>
          </div>
        </div>
      </div>

      {/* Miembros del Hogar */}
      <div className="glass-card rounded-3xl p-6 border border-white/60 flex flex-col gap-4 shadow-xs">
        <h3 className="font-bold text-base text-[#181c1c]">Miembros del Hogar</h3>
        <div className="flex flex-col gap-3">
          {[
            {
              name: "Alex M.",
              role: "Administrador Principal",
              status: "En casa",
              avatar:
                "https://lh3.googleusercontent.com/aida-public/AB6AXuArlVlAtvphSgOD7dSusdI5umrSyGPde4Yl24ewxbXsBkBrbQVgs4eT7xITAEUmrAO4xRwpb_buQgY6ev89nYdPRgBikjaE-WQqjv0Vo4XhMWPFygx8Ntyo9dYCpEMYX-lv3kO_TJkeQhaEAQyrDqIRivXBLBpHTHeLdC_g270RGUNqRbSFLqDVpw-Me9wIJ1DPHKdkHZdYaYvfPkj0T4PxsYFEWwu7P3ztkLwMuASJLzcKQQmuM3jj",
            },
            {
              name: "Sofia R.",
              role: "Miembro de la Familia",
              status: "Fuera de casa",
              avatar:
                "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80",
            },
          ].map((m, idx) => (
            <div
              key={idx}
              className="glass-panel p-3.5 rounded-2xl flex items-center justify-between border border-white/50"
            >
              <div className="flex items-center gap-3">
                <img
                  src={m.avatar}
                  alt={m.name}
                  className="w-10 h-10 rounded-full object-cover border border-white"
                />
                <div>
                  <h4 className="font-bold text-sm text-[#181c1c]">{m.name}</h4>
                  <p className="text-xs text-[#3e4949]">{m.role}</p>
                </div>
              </div>
              <span className="text-xs font-bold text-[#00666b] bg-[#c7e9ec]/60 px-2.5 py-1 rounded-full">
                {m.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
