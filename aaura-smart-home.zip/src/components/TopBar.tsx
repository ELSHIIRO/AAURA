import React from "react";
import { NavTab } from "../types";

interface TopBarProps {
  activeTab: NavTab;
  onOpenNotifications: () => void;
  unreadCount: number;
  onBack?: () => void;
  titleOverride?: string;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onOpenNotifications,
  unreadCount,
  onBack,
  titleOverride,
}) => {
  const titles: Record<NavTab, string> = {
    inicio: "¡Bienvenido de nuevo, Alex!",
    escenas: "Escenas Ambientales",
    dispositivos: "Dispositivos",
    rutinas: "Rutinas Automatizadas",
    historial: "Historial de Actividad",
    ajustes: "Ajustes del Sistema",
    perfil: "Mi Perfil & Hogar",
  };

  const currentTitle = titleOverride || titles[activeTab];

  return (
    <header className="sticky top-0 z-30 w-full bg-[#f7fafa]/80 backdrop-blur-xl border-b border-white/20 transition-all duration-300 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        {onBack && (
          <button
            onClick={onBack}
            className="p-2 text-[#181c1c] rounded-full hover:bg-white/60 transition-colors cursor-pointer"
            title="Volver"
          >
            <span className="material-symbols-outlined text-2xl">
              arrow_back
            </span>
          </button>
        )}
        <div className="flex flex-col">
          <h2 className="font-bold text-xl md:text-2xl text-[#181c1c] tracking-tight">
            {currentTitle}
          </h2>
          {activeTab === "inicio" && !titleOverride && (
            <p className="text-xs md:text-sm text-[#3e4949]">
              Crea ambientes que despiertan tus sentidos.
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={onOpenNotifications}
          className="relative w-11 h-11 rounded-full border border-white/40 glass-card flex items-center justify-center text-[#181c1c] hover:bg-white/80 transition-colors cursor-pointer shadow-xs"
          title="Notificaciones"
        >
          <span className="material-symbols-outlined text-xl">
            notifications
          </span>
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#ba1a1a] text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-xs animate-pulse">
              {unreadCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
