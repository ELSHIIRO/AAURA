import React, { useState } from "react";
import { Scene, ScenesSubView, AudioSoundType } from "../../types";

interface ScenesViewProps {
  scenes: Scene[];
  activeScene: Scene;
  subView: ScenesSubView;
  setSubView: (sub: ScenesSubView) => void;
  onActivateScene: (scene: Scene) => void;
  onSaveNewScene: (newScene: Scene) => void;
  onGenerateAiScene: (prompt: string) => Promise<void>;
  isGeneratingAi: boolean;
}

export const ScenesView: React.FC<ScenesViewProps> = ({
  scenes,
  activeScene,
  subView,
  setSubView,
  onActivateScene,
  onSaveNewScene,
  onGenerateAiScene,
  isGeneratingAi,
}) => {
  // Wizard State
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3>(2); // Default to step 2 as in Image 1
  const [wizTitle, setWizTitle] = useState("Día Lluvioso");
  const [wizDesc, setWizDesc] = useState(
    "Ambiente relajante que simula un día lluvioso con sonidos envolventes, aroma fresco y luces tenues."
  );
  const [wizImage, setWizImage] = useState(
    "https://lh3.googleusercontent.com/aida-public/AB6AXuDY6qRrXqmdC5Z4dxpQI_3OoqZWc-S-Kf9JZSA1Hp9nUHs1SeEkoH4XfNXDVJnK4PNG-DbNP6a8kKaYzD4PpfO7_eP3Dksy0F_zlrC19VVuDDKzC4ecq3jZbS40syGsxoJm-aELsx-65sCLMpy9PTNoUozWQBjWPYCyzwud9rUoxKVwqSXHo4a45hXPgbcV-xdXMD8N4jQf2kPKLU9pLrXDC3ukJKB5CNFK0zgomta6paSEhCmwxZzx"
  );
  const [wizAudioTrack, setWizAudioTrack] = useState("Lluvia en ventana + truenos lejanos");
  const [wizAudioType, setWizAudioType] = useState<AudioSoundType>("rain");
  const [wizVolume, setWizVolume] = useState(40);

  const [wizTemp, setWizTemp] = useState(22);
  const [wizHumidity, setWizHumidity] = useState(65);
  const [wizVent, setWizVent] = useState("Ventilación suave");

  const [wizFragrance, setWizFragrance] = useState("Petricor, musgo y ozono");
  const [wizAromaIntensity, setWizAromaIntensity] = useState(70);

  const [wizLightColor, setWizLightColor] = useState("Gris azulado");
  const [wizLightHex, setWizLightHex] = useState("#5A7184");
  const [wizBrightness, setWizBrightness] = useState(30);
  const [wizColorTemp, setWizColorTemp] = useState<"Frío" | "Templado" | "Cálido">("Frío");

  // AI Prompt Input
  const [aiPromptInput, setAiPromptInput] = useState("");
  const [isListeningMic, setIsListeningMic] = useState(false);

  // Category filter for list mode
  const [filterCat, setFilterCat] = useState<string>("Todas");

  // Handle Wizard Submit
  const handleWizardSave = () => {
    const newScene: Scene = {
      id: `scene-custom-${Date.now()}`,
      title: wizTitle || "Nueva Escena",
      description: wizDesc || "Escena personalizada creada en AAURA",
      imageUrl: wizImage,
      isFavorite: false,
      category: "Sensorial",
      audio: {
        soundType: wizAudioType,
        trackName: wizAudioTrack,
        volume: wizVolume,
      },
      climate: {
        temperature: wizTemp,
        humidity: wizHumidity,
        ventilation: wizVent,
      },
      aroma: {
        fragrance: wizFragrance,
        intensity: wizAromaIntensity,
      },
      lighting: {
        colorName: wizLightColor,
        colorHex: wizLightHex,
        brightness: wizBrightness,
        colorTemp: wizColorTemp,
      },
    };
    onSaveNewScene(newScene);
    setSubView("list");
  };

  // Mic Simulation
  const handleToggleMic = () => {
    if (!isListeningMic) {
      setIsListeningMic(true);
      const samples = [
        "Recrea un día lluvioso de otoño",
        "Atardecer cálido en la playa con olas suaves",
        "Noche de invierno junto al fuego",
        "Bosque al amanecer con niebla fresca",
      ];
      const randomSample = samples[Math.floor(Math.random() * samples.length)];
      setTimeout(() => {
        setAiPromptInput(randomSample);
        setIsListeningMic(false);
      }, 2000);
    } else {
      setIsListeningMic(false);
    }
  };

  // --- SUBVIEW 1: CREATE WITH AI (IMAGE 3) ---
  if (subView === "create_ai") {
    return (
      <div className="flex flex-col min-h-[calc(100vh-100px)] max-w-3xl mx-auto px-4 py-6">
        {/* Top Header */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => setSubView("list")}
            className="flex items-center gap-2 text-[#3e4949] hover:text-[#00666b] transition-colors font-medium text-sm cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg">arrow_back</span>
            Volver
          </button>
          <h2 className="text-xl font-bold text-[#181c1c]">Crear con IA</h2>
          <button
            className="p-2 text-[#3e4949] hover:text-[#00666b] rounded-full transition-colors cursor-pointer"
            title="Información"
          >
            <span className="material-symbols-outlined">info</span>
          </button>
        </div>

        {/* Canvas Body */}
        <div className="flex-1 flex flex-col items-center text-center max-w-xl mx-auto w-full pt-4">
          <h2 className="text-2xl md:text-4xl font-bold text-[#181c1c] mb-2 leading-tight">
            ¿Qué ambiente <br /> quieres{" "}
            <span className="text-[#00666b]">crear</span>?
          </h2>
          <p className="text-sm text-[#3e4949] mb-8">
            Puedes escribir o usar tu voz para sintetizar estímulos de audio, clima, aroma y luz.
          </p>

          {/* Voice Orb Waveform Visualizer */}
          <div
            onClick={handleToggleMic}
            className="relative w-56 h-56 mb-8 flex items-center justify-center cursor-pointer group select-none"
          >
            <div
              className={`absolute inset-0 rounded-full bg-[#00666b]/20 blur-2xl group-hover:bg-[#00666b]/30 transition-all duration-500 ${
                isListeningMic ? "animate-pulse scale-110 bg-[#00666b]/40" : ""
              }`}
            />
            <div className="relative w-44 h-44 rounded-full glass-panel flex items-center justify-center overflow-hidden z-10 border border-white/60 shadow-xl">
              <div className="flex items-center justify-center gap-1.5 h-16 w-32 waveform-animation text-[#00666b]">
                <div className={`w-1.5 bg-[#00666b] rounded-full ${isListeningMic ? "h-14 animate-pulse" : "h-10"}`} />
                <div className={`w-1.5 bg-[#00666b] rounded-full ${isListeningMic ? "h-16 animate-bounce" : "h-14"}`} />
                <div className={`w-1.5 bg-[#00666b] rounded-full ${isListeningMic ? "h-10 animate-pulse" : "h-7"}`} />
                <div className={`w-1.5 bg-[#00666b] rounded-full ${isListeningMic ? "h-16 animate-bounce" : "h-12"}`} />
                <div className={`w-1.5 bg-[#00666b] rounded-full ${isListeningMic ? "h-8 animate-pulse" : "h-5"}`} />
                <div className={`w-1.5 bg-[#00666b]/60 rounded-full ${isListeningMic ? "h-12 animate-bounce" : "h-9"}`} />
                <div className={`w-1.5 bg-[#00666b]/40 rounded-full ${isListeningMic ? "h-14 animate-pulse" : "h-6"}`} />
              </div>
            </div>
            {isListeningMic && (
              <span className="absolute -bottom-6 text-xs font-bold text-[#00666b] animate-pulse">
                Escuchando voz...
              </span>
            )}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (aiPromptInput.trim()) {
                onGenerateAiScene(aiPromptInput);
              }
            }}
            className="w-full relative mb-8"
          >
            <input
              type="text"
              placeholder='Ejemplo: "Recrea un día lluvioso de otoño"'
              value={aiPromptInput}
              onChange={(e) => setAiPromptInput(e.target.value)}
              className="w-full glass-panel rounded-full py-4 pl-6 pr-16 text-sm text-[#181c1c] placeholder:text-[#3e4949]/60 focus:outline-none focus:ring-2 focus:ring-[#00666b] shadow-sm"
            />
            <button
              type="button"
              onClick={handleToggleMic}
              className={`absolute right-12 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
                isListeningMic ? "bg-[#ba1a1a] text-white" : "text-[#00666b] hover:bg-black/5"
              }`}
              title="Micrófono"
            >
              <span className="material-symbols-outlined text-xl symbol-filled">
                mic
              </span>
            </button>
            <button
              type="submit"
              disabled={isGeneratingAi || !aiPromptInput.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 bg-[#00666b] text-white rounded-full flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
              title="Generar Escena"
            >
              {isGeneratingAi ? (
                <span className="material-symbols-outlined text-lg animate-spin">
                  sync
                </span>
              ) : (
                <span className="material-symbols-outlined text-lg">
                  auto_awesome
                </span>
              )}
            </button>
          </form>

          {/* Sugerencias populares */}
          <div className="w-full text-left">
            <h3 className="font-bold text-base text-[#181c1c] mb-4">
              Sugerencias populares
            </h3>
            <div className="flex flex-col gap-3">
              {[
                {
                  title: "Día lluvioso de otoño",
                  icon: "rainy",
                  color: "text-[#2b8085]",
                  prompt: "Recrea un día lluvioso de otoño con sonido ambiental de lluvia en ventana y brisa fresca",
                },
                {
                  title: "Atardecer cálido en la playa",
                  icon: "wb_twilight",
                  color: "text-[#e67e22]",
                  prompt: "Simula un atardecer cálido en la playa con olas suaves, aroma mar y tonos ámbar",
                },
                {
                  title: "Noche de invierno frente a la chimenea",
                  icon: "local_fire_department",
                  color: "text-[#ba1a1a]",
                  prompt: "Atmósfera nocturna de invierno con sonido de leña crujiendo y calidez de fuego",
                },
                {
                  title: "Bosque al amanecer con niebla",
                  icon: "park",
                  color: "text-[#2e7d32]",
                  prompt: "Crea un ambiente de bosque al amanecer con canto de aves, bruma de pino y luz suave",
                },
              ].map((sug, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setAiPromptInput(sug.prompt);
                    onGenerateAiScene(sug.prompt);
                  }}
                  disabled={isGeneratingAi}
                  className="w-full glass-panel flex items-center justify-between p-4 rounded-2xl hover:bg-white/60 transition-all cursor-pointer group text-left border border-white/50"
                >
                  <div className="flex items-center gap-3.5 text-[#181c1c]">
                    <span
                      className={`material-symbols-outlined ${sug.color} text-2xl symbol-filled`}
                    >
                      {sug.icon}
                    </span>
                    <span className="font-medium text-sm">{sug.title}</span>
                  </div>
                  <span className="material-symbols-outlined text-[#3e4949] group-hover:text-[#00666b] transition-colors text-lg">
                    chevron_right
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --- SUBVIEW 2: CREAR ESCENA WIZARD (IMAGE 1) ---
  if (subView === "create_wizard") {
    return (
      <div className="flex flex-col max-w-2xl mx-auto px-4 py-6 pb-32">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => setSubView("list")}
            className="p-2 text-[#181c1c] rounded-full hover:bg-black/5 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-2xl">
              arrow_back
            </span>
          </button>
          <h2 className="text-xl font-bold text-[#181c1c]">Crear Escena</h2>
          <button
            onClick={() => setWizardStep(3)}
            className="text-[#00666b] font-bold text-sm hover:underline cursor-pointer"
          >
            Siguiente
          </button>
        </div>

        {/* Stepper Progress */}
        <div className="flex items-center justify-between px-6 relative mb-8">
          <div className="absolute top-4 left-12 right-12 h-[2px] bg-[#ebeeee] -translate-y-1/2 z-0" />
          <div
            className={`absolute top-4 left-12 h-[2px] bg-[#00666b] -translate-y-1/2 z-0 transition-all duration-300 ${
              wizardStep === 1
                ? "w-0"
                : wizardStep === 2
                ? "w-1/2"
                : "w-full"
            }`}
          />

          {/* Step 1 */}
          <div
            onClick={() => setWizardStep(1)}
            className="flex flex-col items-center gap-1 relative z-10 cursor-pointer"
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                wizardStep >= 1
                  ? "bg-[#00666b] text-white shadow-xs"
                  : "bg-white border text-[#3e4949]"
              }`}
            >
              <span className="material-symbols-outlined text-base">
                check
              </span>
            </div>
            <span className="text-[11px] font-bold text-[#00666b]">
              Descripción
            </span>
          </div>

          {/* Step 2 (Active) */}
          <div
            onClick={() => setWizardStep(2)}
            className="flex flex-col items-center gap-1 relative z-10 cursor-pointer"
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                wizardStep === 2
                  ? "bg-[#00666b] text-white ring-4 ring-[#00666b]/20 shadow-md"
                  : wizardStep > 2
                  ? "bg-[#00666b] text-white"
                  : "bg-white border border-[#bec9c9] text-[#3e4949]"
              }`}
            >
              <span className="material-symbols-outlined text-base">tune</span>
            </div>
            <span className="text-[11px] font-bold text-[#00666b]">
              Personalizar
            </span>
          </div>

          {/* Step 3 */}
          <div
            onClick={() => setWizardStep(3)}
            className="flex flex-col items-center gap-1 relative z-10 cursor-pointer"
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                wizardStep === 3
                  ? "bg-[#00666b] text-white ring-4 ring-[#00666b]/20"
                  : "bg-white border border-[#bec9c9] text-[#3e4949]"
              }`}
            >
              <span>3</span>
            </div>
            <span className="text-[11px] font-medium text-[#3e4949]">
              Vista previa
            </span>
          </div>
        </div>

        {/* Scene Summary Header Card */}
        <section className="flex flex-col gap-6">
          <h3 className="text-xl font-bold text-[#181c1c]">
            Resumen de tu escena
          </h3>

          <div className="glass-panel rounded-2xl p-6 flex items-start gap-4 shadow-xs border border-white/60">
            <div className="flex-1 flex flex-col gap-2 text-left">
              <input
                type="text"
                value={wizTitle}
                onChange={(e) => setWizTitle(e.target.value)}
                className="font-bold text-lg text-[#181c1c] bg-transparent border-b border-dashed border-[#00666b] focus:outline-none"
              />
              <textarea
                value={wizDesc}
                onChange={(e) => setWizDesc(e.target.value)}
                rows={2}
                className="text-xs text-[#3e4949] leading-relaxed bg-transparent focus:outline-none resize-none border-b border-dashed border-gray-300"
              />
            </div>
            <div className="w-20 h-20 rounded-xl overflow-hidden shadow-xs flex-shrink-0 border border-white/60 relative">
              <img
                src={wizImage}
                alt="Escena"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Interactive Parameters List */}
          <div className="flex flex-col gap-4">
            {/* Audio Item */}
            <div className="glass-panel rounded-2xl p-4 flex flex-col gap-3 border border-white/60">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#ebeeee] flex items-center justify-center text-[#00666b] shrink-0">
                  <span className="material-symbols-outlined text-2xl">
                    volume_up
                  </span>
                </div>
                <div className="flex-1 text-left">
                  <h5 className="font-bold text-sm text-[#181c1c]">Audio</h5>
                  <p className="text-xs text-[#3e4949]">{wizAudioTrack}</p>
                </div>
                <span className="text-xs font-bold text-[#00666b]">
                  {wizVolume}%
                </span>
              </div>
              <div className="pt-2 border-t border-white/40 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#3e4949]">Pista de audio:</span>
                  <select
                    value={wizAudioTrack}
                    onChange={(e) => setWizAudioTrack(e.target.value)}
                    className="bg-white/80 rounded-lg px-2 py-1 text-xs text-[#181c1c] border border-white/60"
                  >
                    <option value="Lluvia en ventana + truenos lejanos">
                      Lluvia en ventana + truenos lejanos
                    </option>
                    <option value="Olas rítmicas en la orilla + brisa">
                      Olas rítmicas en la orilla + brisa
                    </option>
                    <option value="Canto de aves silvestres + viento en copas">
                      Canto de aves silvestres + viento en copas
                    </option>
                    <option value="Crujido de leña + viento invernal">
                      Crujido de leña + viento invernal
                    </option>
                  </select>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-[#3e4949] w-16">Volumen:</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={wizVolume}
                    onChange={(e) => setWizVolume(Number(e.target.value))}
                    className="w-full h-1.5 bg-[#bec9c9]/50 rounded-lg appearance-none accent-[#00666b]"
                  />
                </div>
              </div>
            </div>

            {/* Clima Item */}
            <div className="glass-panel rounded-2xl p-4 flex flex-col gap-3 border border-white/60">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#ebeeee] flex items-center justify-center text-[#e67e22] shrink-0">
                  <span className="material-symbols-outlined text-2xl">
                    thermostat
                  </span>
                </div>
                <div className="flex-1 text-left">
                  <h5 className="font-bold text-sm text-[#181c1c]">Clima</h5>
                  <p className="text-xs text-[#3e4949]">
                    {wizTemp}°C • Humedad {wizHumidity}% • {wizVent}
                  </p>
                </div>
                <span className="text-xs font-bold text-[#e67e22]">
                  {wizTemp}°C
                </span>
              </div>
              <div className="pt-2 border-t border-white/40 flex flex-col gap-2">
                <div className="flex items-center gap-3">
                  <span className="text-xs text-[#3e4949] w-20">Temperatura:</span>
                  <input
                    type="range"
                    min="18"
                    max="28"
                    value={wizTemp}
                    onChange={(e) => setWizTemp(Number(e.target.value))}
                    className="w-full h-1.5 bg-[#bec9c9]/50 rounded-lg appearance-none accent-[#e67e22]"
                  />
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-[#3e4949] w-20">Humedad:</span>
                  <input
                    type="range"
                    min="30"
                    max="90"
                    value={wizHumidity}
                    onChange={(e) => setWizHumidity(Number(e.target.value))}
                    className="w-full h-1.5 bg-[#bec9c9]/50 rounded-lg appearance-none accent-[#e67e22]"
                  />
                </div>
              </div>
            </div>

            {/* Aroma Item */}
            <div className="glass-panel rounded-2xl p-4 flex flex-col gap-3 border border-white/60">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#ebeeee] flex items-center justify-center text-[#9b59b6] shrink-0">
                  <span className="material-symbols-outlined text-2xl">
                    air
                  </span>
                </div>
                <div className="flex-1 text-left">
                  <h5 className="font-bold text-sm text-[#181c1c]">Aroma</h5>
                  <p className="text-xs text-[#3e4949]">{wizFragrance}</p>
                </div>
                <span className="text-xs font-bold text-[#9b59b6]">
                  {wizAromaIntensity}%
                </span>
              </div>
              <div className="pt-2 border-t border-white/40 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#3e4949]">Fragancia:</span>
                  <select
                    value={wizFragrance}
                    onChange={(e) => setWizFragrance(e.target.value)}
                    className="bg-white/80 rounded-lg px-2 py-1 text-xs text-[#181c1c] border border-white/60"
                  >
                    <option value="Petricor, musgo y ozono">
                      Petricor, musgo y ozono
                    </option>
                    <option value="Sal marina, floripondio y coco">
                      Sal marina, floripondio y coco
                    </option>
                    <option value="Eucalipto, musgo y pino fresco">
                      Eucalipto, musgo y pino fresco
                    </option>
                    <option value="Madera de cedro, vainilla y canela">
                      Madera de cedro, vainilla y canela
                    </option>
                  </select>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-[#3e4949] w-16">Intensidad:</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={wizAromaIntensity}
                    onChange={(e) => setWizAromaIntensity(Number(e.target.value))}
                    className="w-full h-1.5 bg-[#bec9c9]/50 rounded-lg appearance-none accent-[#9b59b6]"
                  />
                </div>
              </div>
            </div>

            {/* Iluminación Item */}
            <div className="glass-panel rounded-2xl p-4 flex flex-col gap-3 border border-white/60">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#ebeeee] flex items-center justify-center text-[#f1c40f] shrink-0">
                  <span className="material-symbols-outlined text-2xl symbol-filled">
                    lightbulb
                  </span>
                </div>
                <div className="flex-1 text-left">
                  <h5 className="font-bold text-sm text-[#181c1c]">
                    Iluminación
                  </h5>
                  <p className="text-xs text-[#3e4949]">
                    {wizLightColor} • Brillo {wizBrightness}%
                  </p>
                </div>
                <span className="text-xs font-bold text-[#d4ac0d]">
                  {wizBrightness}%
                </span>
              </div>
              <div className="pt-2 border-t border-white/40 flex flex-col gap-2">
                <div className="flex items-center gap-3">
                  <span className="text-xs text-[#3e4949] w-16">Brillo:</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={wizBrightness}
                    onChange={(e) => setWizBrightness(Number(e.target.value))}
                    className="w-full h-1.5 bg-[#bec9c9]/50 rounded-lg appearance-none accent-[#f1c40f]"
                  />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#3e4949]">Tono de Luz:</span>
                  <div className="flex gap-2">
                    {(["Frío", "Templado", "Cálido"] as const).map((temp) => (
                      <button
                        key={temp}
                        type="button"
                        onClick={() => setWizColorTemp(temp)}
                        className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                          wizColorTemp === temp
                            ? "bg-[#00666b] text-white"
                            : "bg-white/60 text-[#3e4949]"
                        }`}
                      >
                        {temp}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Sticky Bottom Actions */}
        <div className="fixed bottom-0 left-0 md:left-64 right-0 p-6 bg-gradient-to-t from-[#f7fafa] via-[#f7fafa]/90 to-transparent z-30 pb-8">
          <div className="max-w-2xl mx-auto flex flex-col gap-3">
            <button
              onClick={handleWizardSave}
              className="w-full bg-[#00666b] text-white font-bold text-base py-4 rounded-xl shadow-lg shadow-[#00666b]/20 hover:bg-[#2b8085] transition-all active:scale-[0.98] cursor-pointer"
            >
              Guardar Escena
            </button>
            <button
              onClick={() => setSubView("list")}
              className="w-full bg-transparent text-[#00666b] font-bold text-sm py-2 rounded-xl hover:bg-black/5 transition-colors cursor-pointer"
            >
              Cancelar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- SUBVIEW 0: MAIN SCENES LIST ---
  const filteredScenes = scenes.filter((sc) => {
    if (filterCat === "Todas") return true;
    if (filterCat === "Favoritas") return sc.isFavorite;
    return sc.category === filterCat;
  });

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto px-4 md:px-8 py-6 pb-32">
      {/* Action Banner Header */}
      <div className="glass-card rounded-3xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-white/60 shadow-sm relative overflow-hidden">
        <div className="flex flex-col text-left gap-2 z-10">
          <span className="text-xs uppercase font-bold tracking-wider text-[#00666b]">
            Estudio Sensorial AAURA
          </span>
          <h2 className="text-2xl md:text-3xl font-bold text-[#181c1c]">
            Explora y diseña tus ambientes
          </h2>
          <p className="text-sm text-[#3e4949] max-w-md">
            Crea experiencias inmersivas personalizando audio, clima, fragancia e iluminación en tiempo real.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 z-10 w-full md:w-auto">
          <button
            onClick={() => setSubView("create_ai")}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 bg-[#00666b] text-white font-bold text-sm px-5 py-3 rounded-2xl shadow-md hover:bg-[#2b8085] transition-all active:scale-95 cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg symbol-filled">
              auto_awesome
            </span>
            Crear con IA
          </button>
          <button
            onClick={() => setSubView("create_wizard")}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 glass-panel text-[#00666b] font-bold text-sm px-5 py-3 rounded-2xl hover:bg-white/80 transition-all active:scale-95 cursor-pointer border border-white/60"
          >
            <span className="material-symbols-outlined text-lg">add</span>
            Crear Manual
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {["Todas", "Favoritas", "Sensorial", "Relajación", "Noche"].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCat(cat)}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              filterCat === cat
                ? "bg-[#00666b] text-white shadow-xs"
                : "glass-panel text-[#3e4949] hover:bg-white/80"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Scenes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {filteredScenes.map((scene) => {
          const isActive = activeScene.id === scene.id;
          return (
            <div
              key={scene.id}
              className={`glass-card rounded-3xl p-6 flex flex-col justify-between gap-4 border transition-all duration-300 hover:shadow-md relative ${
                isActive ? "border-[#00666b] ring-2 ring-[#00666b]/30" : "border-white/60"
              }`}
            >
              <div className="flex gap-4 items-start">
                <div className="w-24 h-24 rounded-2xl overflow-hidden shadow-xs shrink-0 border border-white/60 relative">
                  <img
                    src={scene.imageUrl}
                    alt={scene.title}
                    className="w-full h-full object-cover"
                  />
                  {isActive && (
                    <span className="absolute top-1.5 left-1.5 bg-[#00666b] text-white text-[9px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                      Activa
                    </span>
                  )}
                </div>

                <div className="flex-1 text-left flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-[#00666b] tracking-wider">
                      {scene.category}
                    </span>
                    <span className="text-xs font-semibold text-[#3e4949]">
                      {scene.lighting.colorName}
                    </span>
                  </div>
                  <h3 className="font-bold text-lg text-[#181c1c]">
                    {scene.title}
                  </h3>
                  <p className="text-xs text-[#3e4949] line-clamp-2 leading-relaxed">
                    {scene.description}
                  </p>
                </div>
              </div>

              {/* Parameter Chips */}
              <div className="grid grid-cols-4 gap-2 pt-3 border-t border-white/40 text-center text-[11px] font-medium text-[#3e4949]">
                <div className="bg-white/50 rounded-xl p-2 flex flex-col items-center">
                  <span className="material-symbols-outlined text-base text-[#00666b] mb-0.5">
                    volume_up
                  </span>
                  <span>{scene.audio.volume}%</span>
                </div>
                <div className="bg-white/50 rounded-xl p-2 flex flex-col items-center">
                  <span className="material-symbols-outlined text-base text-[#e67e22] mb-0.5">
                    thermostat
                  </span>
                  <span>{scene.climate.temperature}°C</span>
                </div>
                <div className="bg-white/50 rounded-xl p-2 flex flex-col items-center">
                  <span className="material-symbols-outlined text-base text-[#9b59b6] mb-0.5">
                    air
                  </span>
                  <span>{scene.aroma.intensity}%</span>
                </div>
                <div className="bg-white/50 rounded-xl p-2 flex flex-col items-center">
                  <span className="material-symbols-outlined text-base text-[#d4ac0d] mb-0.5 symbol-filled">
                    lightbulb
                  </span>
                  <span>{scene.lighting.brightness}%</span>
                </div>
              </div>

              {/* Action */}
              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => onActivateScene(scene)}
                  className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    isActive
                      ? "bg-[#c7e9ec] text-[#004f53]"
                      : "bg-[#00666b] text-white hover:bg-[#2b8085]"
                  }`}
                >
                  <span className="material-symbols-outlined text-base symbol-filled">
                    {isActive ? "check_circle" : "play_arrow"}
                  </span>
                  {isActive ? "Escena Activa en el Hogar" : "Activar esta Escena"}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
