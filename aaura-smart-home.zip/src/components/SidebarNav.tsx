import React from "react";
import { NavTab } from "../types";

interface SidebarNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  unreadCount: number;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  onSelectTab,
}) => {
  const navItems: { id: NavTab; label: string; icon: string }[] = [
    { id: "inicio", label: "Inicio", icon: "home" },
    { id: "escenas", label: "Escenas", icon: "auto_awesome" },
    { id: "dispositivos", label: "Dispositivos", icon: "devices" },
    { id: "rutinas", label: "Rutinas", icon: "schedule" },
    { id: "historial", label: "Historial", icon: "history" },
    { id: "ajustes", label: "Ajustes", icon: "settings" },
  ];

  return (
    <nav className="hidden md:flex flex-col w-64 h-full fixed left-0 top-0 border-r border-white/20 bg-[#ebeeee]/70 backdrop-blur-2xl shadow-sm z-40 select-none">
      {/* Brand Header */}
      <div className="flex items-center gap-3 p-6 mb-2 mt-2">
        <div className="w-10 h-10 rounded-full bg-[#2b8085] flex items-center justify-center text-[#f4ffff] shadow-sm">
          <span className="material-symbols-outlined text-2xl symbol-filled">
            auto_awesome
          </span>
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#00666b]">
            AAURA
          </h1>
          <p className="text-[10px] text-[#3e4949] font-bold tracking-widest uppercase">
            Premium Smart Home
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex-1 flex flex-col gap-1.5 px-3 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 text-left w-full cursor-pointer ${
                isActive
                  ? "bg-[#c7e9ec]/60 text-[#004f53] font-bold shadow-xs scale-[1.01]"
                  : "text-[#3e4949] hover:bg-white/40 hover:text-[#181c1c]"
              }`}
            >
              <span
                className={`material-symbols-outlined text-2xl ${
                  isActive ? "symbol-filled text-[#00666b]" : ""
                }`}
              >
                {item.icon}
              </span>
              <span className="text-base font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Footer Profile */}
      <div className="p-4 border-t border-white/20">
        <button
          onClick={() => onSelectTab("perfil")}
          className={`flex items-center gap-3.5 w-full p-2.5 rounded-xl transition-all duration-200 cursor-pointer ${
            activeTab === "perfil"
              ? "bg-[#c7e9ec]/60 text-[#004f53] font-bold"
              : "hover:bg-white/40 text-[#3e4949]"
          }`}
        >
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuArlVlAtvphSgOD7dSusdI5umrSyGPde4Yl24ewxbXsBkBrbQVgs4eT7xITAEUmrAO4xRwpb_buQgY6ev89nYdPRgBikjaE-WQqjv0Vo4XhMWPFygx8Ntyo9dYCpEMYX-lv3kO_TJkeQhaEAQyrDqIRivXBLBpHTHeLdC_g270RGUNqRbSFLqDVpw-Me9wIJ1DPHKdkHZdYaYvfPkj0T4PxsYFEWwu7P3ztkLwMuASJLzcKQQmuM3jj"
            alt="Alex Profile"
            className="w-9 h-9 rounded-full object-cover border border-white/60 shadow-xs"
          />
          <div className="flex flex-col text-left">
            <span className="text-sm font-semibold text-[#181c1c]">Alex</span>
            <span className="text-[11px] text-[#00666b] font-medium">
              Ver perfil ▾
            </span>
          </div>
        </button>
      </div>
    </nav>
  );
};
