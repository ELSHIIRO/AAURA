import React, { useState } from "react";
import { Routine, Scene } from "../../types";

interface RoutinesViewProps {
  routines: Routine[];
  scenes: Scene[];
  onToggleRoutine: (id: string) => void;
  onRunRoutineNow: (routine: Routine) => void;
  onAddRoutine: (newRot: Routine) => void;
}

export const RoutinesView: React.FC<RoutinesViewProps> = ({
  routines,
  scenes,
  onToggleRoutine,
  onRunRoutineNow,
  onAddRoutine,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [title, setTitle] = useState("");
  const [schedule, setSchedule] = useState("Todos los días a las 08:00 AM");
  const [sceneId, setSceneId] = useState(scenes[0]?.id || "");

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const matchedScene = scenes.find((s) => s.id === sceneId);

    const newRot: Routine = {
      id: `rot-${Date.now()}`,
      title: title.trim(),
      description: `Activa la escena '${matchedScene?.title || "Sensorial"}' según el horario programado.`,
      schedule,
      icon: "schedule",
      isActive: true,
      sceneId,
      days: ["Lun", "Mar", "Mié", "Jue", "Vie"],
    };

    onAddRoutine(newRot);
    setTitle("");
    setShowAddForm(false);
  };

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto px-4 md:px-8 py-6 pb-32 text-left">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#181c1c]">
            Rutinas Automatizadas
          </h2>
          <p className="text-xs text-[#3e4949]">
            Programa cambios ambientales automáticos según tus horarios y hábitos diarios.
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-1.5 bg-[#00666b] text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-xs hover:bg-[#2b8085] transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-lg">add</span>
          Nueva Rutina
        </button>
      </div>

      {showAddForm && (
        <form
          onSubmit={handleCreate}
          className="glass-card rounded-3xl p-6 border border-white/60 flex flex-col gap-4 shadow-md animate-[fadeIn_0.2s_ease-out]"
        >
          <h3 className="font-bold text-base text-[#181c1c]">
            Crear Nueva Rutina
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-[#3e4949] mb-1">
                Nombre de la Rutina
              </label>
              <input
                type="text"
                required
                placeholder="Ej: Siesta de la Tarde, Meditación"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full glass-panel rounded-xl py-2.5 px-3 text-sm text-[#181c1c] focus:outline-none focus:ring-2 focus:ring-[#00666b]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-[#3e4949] mb-1">
                Escena Asociada
              </label>
              <select
                value={sceneId}
                onChange={(e) => setSceneId(e.target.value)}
                className="w-full glass-panel rounded-xl py-2.5 px-3 text-sm text-[#181c1c] focus:outline-none focus:ring-2 focus:ring-[#00666b]"
              >
                {scenes.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-[#3e4949] mb-1">
              Horario / Disparador
            </label>
            <input
              type="text"
              value={schedule}
              onChange={(e) => setSchedule(e.target.value)}
              className="w-full glass-panel rounded-xl py-2.5 px-3 text-sm text-[#181c1c] focus:outline-none focus:ring-2 focus:ring-[#00666b]"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="w-1/2 py-2.5 glass-panel rounded-xl text-xs font-bold text-[#3e4949] hover:bg-white/60 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="w-1/2 py-2.5 bg-[#00666b] text-white rounded-xl text-xs font-bold shadow-xs hover:bg-[#2b8085] cursor-pointer"
            >
              Guardar Rutina
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {routines.map((rot) => (
          <div
            key={rot.id}
            className={`glass-card rounded-3xl p-6 flex flex-col justify-between gap-4 border transition-all ${
              rot.isActive ? "border-white/60" : "border-gray-200 opacity-60"
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-[#00666b]/15 flex items-center justify-center text-[#00666b]">
                  <span className="material-symbols-outlined text-2xl">
                    {rot.icon}
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#181c1c]">
                    {rot.title}
                  </h3>
                  <span className="text-xs text-[#00666b] font-bold">
                    {rot.schedule}
                  </span>
                </div>
              </div>
              <button
                onClick={() => onToggleRoutine(rot.id)}
                className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                  rot.isActive ? "bg-[#00666b]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    rot.isActive ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            <p className="text-xs text-[#3e4949] leading-relaxed">
              {rot.description}
            </p>

            <div className="flex items-center justify-between pt-2 border-t border-white/40">
              <div className="flex gap-1">
                {rot.days.map((day, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-bold bg-white/60 px-2 py-0.5 rounded-full text-[#3e4949]"
                  >
                    {day}
                  </span>
                ))}
              </div>
              <button
                onClick={() => onRunRoutineNow(rot)}
                className="text-xs font-bold text-[#00666b] hover:underline flex items-center gap-1 cursor-pointer"
              >
                Ejecutar ahora
                <span className="material-symbols-outlined text-sm">
                  play_arrow
                </span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
