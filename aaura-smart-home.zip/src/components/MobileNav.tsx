import React from "react";
import { NavTab } from "../types";

interface MobileNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  onSelectTab,
}) => {
  const items: { id: NavTab; label: string; icon: string }[] = [
    { id: "inicio", label: "Inicio", icon: "home" },
    { id: "escenas", label: "Escenas", icon: "auto_awesome" },
    { id: "dispositivos", label: "Dispos.", icon: "devices" },
    { id: "rutinas", label: "Rutinas", icon: "schedule" },
    { id: "ajustes", label: "Ajustes", icon: "settings" },
  ];

  return (
    <nav className="md:hidden fixed bottom-4 left-1/2 -translate-x-1/2 w-[92%] max-w-md rounded-full bg-[#e6e9e8]/90 backdrop-blur-2xl border border-white/40 shadow-2xl flex items-center justify-around px-3 py-2 z-40">
      {items.map((item) => {
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onSelectTab(item.id)}
            className={`flex flex-col items-center justify-center p-1.5 rounded-full transition-transform active:scale-95 cursor-pointer ${
              isActive ? "text-[#00666b] font-bold" : "text-[#3e4949]"
            }`}
          >
            <span
              className={`material-symbols-outlined text-2xl mb-0.5 ${
                isActive ? "symbol-filled" : ""
              }`}
            >
              {item.icon}
            </span>
            <span className="text-[10px] font-medium leading-none">
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
