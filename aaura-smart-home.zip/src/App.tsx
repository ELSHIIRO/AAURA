import React, { useState } from "react";
import {
  NavTab,
  ScenesSubView,
  Scene,
  SonosDevice,
  NestThermostatDevice,
  PuraDiffuserDevice,
  HueLightingDevice,
  SmartDeviceItem,
  Routine,
  HistoryLog,
  NotificationItem,
  AudioPlayerState,
} from "./types";
import {
  initialScenes,
  initialSonosDevice,
  initialNestThermostat,
  initialPuraDiffuser,
  initialHueLighting,
  initialSmartDevices,
  initialRoutines,
  initialHistoryLogs,
  initialNotifications,
} from "./data/mockData";
import { audioEngine } from "./utils/audioEngine";
import { SidebarNav } from "./components/SidebarNav";
import { MobileNav } from "./components/MobileNav";
import { TopBar } from "./components/TopBar";
import { BottomPlayer } from "./components/BottomPlayer";
import { NotificationCenter } from "./components/NotificationCenter";
import { AddDeviceModal } from "./components/AddDeviceModal";

import { HomeView } from "./components/views/HomeView";
import { ScenesView } from "./components/views/ScenesView";
import { DevicesView } from "./components/views/DevicesView";
import { RoutinesView } from "./components/views/RoutinesView";
import { HistoryView } from "./components/views/HistoryView";
import { SettingsView } from "./components/views/SettingsView";
import { ProfileView } from "./components/views/ProfileView";

export function App() {
  // Navigation & Sub-views
  const [activeTab, setActiveTab] = useState<NavTab>("inicio");
  const [scenesSubView, setScenesSubView] = useState<ScenesSubView>("list");

  // Core Data State
  const [scenes, setScenes] = useState<Scene[]>(initialScenes);
  const [activeScene, setActiveScene] = useState<Scene>(initialScenes[0]);

  // Devices State
  const [sonos, setSonos] = useState<SonosDevice>(initialSonosDevice);
  const [nest, setNest] = useState<NestThermostatDevice>(initialNestThermostat);
  const [pura, setPura] = useState<PuraDiffuserDevice>(initialPuraDiffuser);
  const [hue, setHue] = useState<HueLightingDevice>(initialHueLighting);
  const [customDevices, setCustomDevices] = useState<SmartDeviceItem[]>(initialSmartDevices);

  // Routines & History & Notifications
  const [routines, setRoutines] = useState<Routine[]>(initialRoutines);
  const [logs, setLogs] = useState<HistoryLog[]>(initialHistoryLogs);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initialNotifications);

  // UI Modals
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isAddDeviceOpen, setIsAddDeviceOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Audio Player State
  const [playerState, setPlayerState] = useState<AudioPlayerState>({
    isPlaying: false,
    sceneId: initialScenes[0].id,
    sceneTitle: initialScenes[0].title,
    trackName: initialScenes[0].audio.trackName,
    volume: initialScenes[0].audio.volume,
    isMuted: false,
    imageUrl: initialScenes[0].imageUrl,
    audioType: initialScenes[0].audio.soundType,
  });

  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  // Show Toast helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Add History Log helper
  const addLog = (
    title: string,
    description: string,
    category: HistoryLog["category"],
    icon: string
  ) => {
    const newLog: HistoryLog = {
      id: `log-${Date.now()}`,
      timestamp: "Ahora mismo",
      title,
      description,
      category,
      icon,
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // --- ACTIVATE SCENE ---
  const handleActivateScene = (scene: Scene) => {
    setActiveScene(scene);

    // Sync Devices with Scene Parameters
    setSonos((prev) => ({
      ...prev,
      volume: scene.audio.volume,
      currentTrack: scene.audio.trackName,
      isPoweredOn: true,
    }));

    setNest((prev) => ({
      ...prev,
      targetTemp: scene.climate.temperature,
      humidity: scene.climate.humidity,
      isPoweredOn: true,
    }));

    setPura((prev) => ({
      ...prev,
      intensity: scene.aroma.intensity,
      isPoweredOn: true,
    }));

    setHue((prev) => ({
      ...prev,
      brightness: scene.lighting.brightness,
      colorName: scene.lighting.colorName,
      colorHex: scene.lighting.colorHex,
      colorTemp: scene.lighting.colorTemp,
      isPoweredOn: true,
    }));

    // Play Audio via Web Audio Engine
    audioEngine.play(scene.audio.soundType, scene.audio.volume);

    setPlayerState({
      isPlaying: true,
      sceneId: scene.id,
      sceneTitle: scene.title,
      trackName: scene.audio.trackName,
      volume: scene.audio.volume,
      isMuted: false,
      imageUrl: scene.imageUrl,
      audioType: scene.audio.soundType,
    });

    showToast(`Escena '${scene.title}' activada en todo el hogar.`);
    addLog(
      `Escena Activada: ${scene.title}`,
      `Ajustados audio (${scene.audio.volume}%), clima (${scene.climate.temperature}°C), aroma (${scene.aroma.intensity}%) y luces.`,
      "escena",
      "auto_awesome"
    );
  };

  // --- AUDIO CONTROLS ---
  const handleTogglePlay = () => {
    if (playerState.isPlaying) {
      audioEngine.stop();
      setPlayerState((prev) => ({ ...prev, isPlaying: false }));
    } else {
      audioEngine.play(playerState.audioType, playerState.volume);
      setPlayerState((prev) => ({ ...prev, isPlaying: true }));
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setPlayerState((prev) => ({ ...prev, volume: newVol }));
    audioEngine.setVolume(newVol);
  };

  // --- SAVE NEW WIZARD SCENE ---
  const handleSaveNewScene = (newScene: Scene) => {
    setScenes((prev) => [newScene, ...prev]);
    handleActivateScene(newScene);
    showToast(`Nueva escena '${newScene.title}' creada e instalada.`);
  };

  // --- GENERATE AI SCENE VIA EXPRESS API ---
  const handleGenerateAiScene = async (prompt: string) => {
    setIsGeneratingAi(true);
    try {
      const res = await fetch("/api/generate-scene", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();

      const aiScene: Scene = {
        id: `scene-ai-${Date.now()}`,
        title: data.title || "Ambiente IA",
        description: data.description || prompt,
        imageUrl: data.imageUrl,
        isFavorite: false,
        category: "IA Generada",
        audio: {
          soundType: data.audioType || "rain",
          trackName: data.audioTrackName || "Audio ambiental sintetizado",
          volume: data.volume || 45,
        },
        climate: {
          temperature: data.temperature || 22,
          humidity: data.humidity || 60,
          ventilation: data.ventilation || "Brisa suave",
        },
        aroma: {
          fragrance: data.fragrance || "Lavanda y Sal Marina",
          intensity: data.intensity || 70,
        },
        lighting: {
          colorName: data.lightColorName || "Cálido",
          colorHex: "#00666b",
          brightness: data.brightness || 40,
          colorTemp: data.lightColorTemp || "Cálido",
        },
      };

      setScenes((prev) => [aiScene, ...prev]);
      handleActivateScene(aiScene);
      addLog(
        "Escena Generada por IA",
        `Instrucción: "${prompt}" -> Creada escena '${aiScene.title}'`,
        "ia",
        "auto_awesome"
      );
      setScenesSubView("list");
    } catch (err) {
      console.error("Error invoking AI scene generator:", err);
      showToast("No se pudo generar la escena por IA. Reintenta.");
    } finally {
      setIsGeneratingAi(false);
    }
  };

  // Unread count
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-[#ebeeee] text-[#181c1c] font-sans antialiased flex flex-col md:flex-row relative overflow-x-hidden selection:bg-[#00666b]/20">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-[#00666b] text-white px-6 py-3 rounded-2xl shadow-xl flex items-center gap-3 border border-white/30 animate-[slideDown_0.3s_ease-out]">
          <span className="material-symbols-outlined text-xl symbol-filled">
            check_circle
          </span>
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Desktop Sidebar Navigation */}
      <SidebarNav
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab === "escenas") setScenesSubView("list");
        }}
        unreadCount={unreadCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 md:ml-64 flex flex-col min-h-screen transition-all">
        {/* Top Header Bar */}
        <TopBar
          activeTab={activeTab}
          onOpenNotifications={() => setIsNotifOpen(true)}
          unreadCount={unreadCount}
          onBack={
            activeTab === "escenas" && scenesSubView !== "list"
              ? () => setScenesSubView("list")
              : undefined
          }
          titleOverride={
            activeTab === "escenas" && scenesSubView === "create_wizard"
              ? "Crear Escena"
              : activeTab === "escenas" && scenesSubView === "create_ai"
              ? "Crear con IA"
              : undefined
          }
        />

        {/* Dynamic Tab Views */}
        <main className="flex-1 w-full">
          {activeTab === "inicio" && (
            <HomeView
              scenes={scenes}
              activeScene={activeScene}
              playerState={playerState}
              onActivateScene={handleActivateScene}
              onNavigateTab={(tab) => {
                setActiveTab(tab);
                if (tab === "escenas") setScenesSubView("list");
              }}
              onOpenSceneDetails={(scene) => {
                setActiveScene(scene);
                setActiveTab("escenas");
                setScenesSubView("list");
              }}
            />
          )}

          {activeTab === "escenas" && (
            <ScenesView
              scenes={scenes}
              activeScene={activeScene}
              subView={scenesSubView}
              setSubView={setScenesSubView}
              onActivateScene={handleActivateScene}
              onSaveNewScene={handleSaveNewScene}
              onGenerateAiScene={handleGenerateAiScene}
              isGeneratingAi={isGeneratingAi}
            />
          )}

          {activeTab === "dispositivos" && (
            <DevicesView
              sonos={sonos}
              nest={nest}
              pura={pura}
              hue={hue}
              customDevices={customDevices}
              onUpdateSonos={(upd) => setSonos((prev) => ({ ...prev, ...upd }))}
              onUpdateNest={(upd) => setNest((prev) => ({ ...prev, ...upd }))}
              onUpdatePura={(upd) => setPura((prev) => ({ ...prev, ...upd }))}
              onUpdateHue={(upd) => setHue((prev) => ({ ...prev, ...upd }))}
              onToggleCustomDevice={(id) =>
                setCustomDevices((prev) =>
                  prev.map((d) =>
                    d.id === id ? { ...d, isPoweredOn: !d.isPoweredOn } : d
                  )
                )
              }
              onOpenAddModal={() => setIsAddDeviceOpen(true)}
            />
          )}

          {activeTab === "rutinas" && (
            <RoutinesView
              routines={routines}
              scenes={scenes}
              onToggleRoutine={(id) =>
                setRoutines((prev) =>
                  prev.map((r) =>
                    r.id === id ? { ...r, isActive: !r.isActive } : r
                  )
                )
              }
              onRunRoutineNow={(rot) => {
                const targetSc = scenes.find((s) => s.id === rot.sceneId);
                if (targetSc) {
                  handleActivateScene(targetSc);
                  showToast(`Rutina '${rot.title}' ejecutada.`);
                }
              }}
              onAddRoutine={(newRot) => {
                setRoutines((prev) => [newRot, ...prev]);
                showToast("Rutina programada exitosamente.");
              }}
            />
          )}

          {activeTab === "historial" && (
            <HistoryView logs={logs} onClearLogs={() => setLogs([])} />
          )}

          {activeTab === "ajustes" && <SettingsView />}

          {activeTab === "perfil" && <ProfileView />}
        </main>
      </div>

      {/* Floating Ambient Audio Player */}
      <BottomPlayer
        playerState={playerState}
        onTogglePlay={handleTogglePlay}
        onVolumeChange={handleVolumeChange}
      />

      {/* Mobile Floating Bottom Bar */}
      <MobileNav
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab === "escenas") setScenesSubView("list");
        }}
      />

      {/* Notification Center Slide Panel */}
      <NotificationCenter
        isOpen={isNotifOpen}
        onClose={() => setIsNotifOpen(false)}
        notifications={notifications}
        onMarkAllRead={() =>
          setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
        }
        onClearNotif={(id) =>
          setNotifications((prev) => prev.filter((n) => n.id !== id))
        }
      />

      {/* Add Device Modal */}
      <AddDeviceModal
        isOpen={isAddDeviceOpen}
        onClose={() => setIsAddDeviceOpen(false)}
        onAddDevice={(dev) => {
          setCustomDevices((prev) => [dev, ...prev]);
          showToast(`Dispositivo '${dev.name}' vinculado.`);
        }}
      />
    </div>
  );
}

export default App;
