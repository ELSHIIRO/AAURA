import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI Client lazily or safely
  let genAIClient: GoogleGenAI | null = null;
  function getGenAI() {
    if (!genAIClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        console.warn("GEMINI_API_KEY not set in environment.");
      }
      genAIClient = new GoogleGenAI({
        apiKey: apiKey || "placeholder",
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return genAIClient;
  }

  // Health API
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "AAURA Smart Home" });
  });

  // AI Scene Generator API
  app.post("/api/generate-scene", async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt || typeof prompt !== "string") {
        return res.status(400).json({ error: "El prompt es requerido." });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
        // Fallback intelligent scene generator if no valid API key is present
        const generatedFallback = generateSmartFallbackScene(prompt);
        return res.json(generatedFallback);
      }

      const ai = getGenAI();
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: `Eres el motor de IA de AAURA Premium Smart Home. Basándote en la solicitud del usuario "${prompt}", genera una escena ambiental sensorial estructurada en JSON.
Los valores deben ajustarse a la experiencia solicitada:
- title: nombre de la escena en español (2-4 palabras)
- description: descripción evocadora (15-30 palabras)
- audioType: tipo de audio ('rain' | 'waves' | 'forest' | 'fireplace' | 'wind' | 'chill')
- audioTrackName: nombre del track de audio (ej: "Lluvia suave en ventana + truenos lejanos")
- volume: número entre 10 y 100
- temperature: número entero entre 18 y 26 (°C)
- humidity: número entero entre 40 y 85 (%)
- ventilation: texto corto (ej: "Ventilación suave", "Brisa fresca", "Aire templado")
- fragrance: nombre del aroma (ej: "Petricor, musgo y ozono", "Jazmín y sal marina", "Pino y eucalipto")
- intensity: número entero entre 20 y 100
- lightColorName: nombre del color de luz (ej: "Gris azulado", "Naranja atardecer", "Blanco cálido 2700K")
- brightness: número entero entre 10 y 100
- lightColorTemp: texto ("Frío" | "Templado" | "Cálido")
- imageUrl: URL de imagen ambiental adecuada`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              audioType: { type: Type.STRING },
              audioTrackName: { type: Type.STRING },
              volume: { type: Type.INTEGER },
              temperature: { type: Type.INTEGER },
              humidity: { type: Type.INTEGER },
              ventilation: { type: Type.STRING },
              fragrance: { type: Type.STRING },
              intensity: { type: Type.INTEGER },
              lightColorName: { type: Type.STRING },
              brightness: { type: Type.INTEGER },
              lightColorTemp: { type: Type.STRING },
              imageUrl: { type: Type.STRING },
            },
            required: [
              "title",
              "description",
              "audioType",
              "audioTrackName",
              "volume",
              "temperature",
              "humidity",
              "ventilation",
              "fragrance",
              "intensity",
              "lightColorName",
              "brightness",
              "lightColorTemp",
            ],
          },
        },
      });

      const text = response.text || "";
      let parsed = JSON.parse(text);

      // Ensure fallback image if missing or invalid
      if (!parsed.imageUrl) {
        parsed.imageUrl = getStockAmbientImage(parsed.audioType || "rain");
      }

      return res.json(parsed);
    } catch (err: any) {
      console.error("Error generating scene with Gemini:", err);
      // Seamless fallback response on error
      const generatedFallback = generateSmartFallbackScene(req.body.prompt || "Ambiente relajante");
      return res.json(generatedFallback);
    }
  });

  // Helper stock ambient images
  function getStockAmbientImage(type: string): string {
    const images: Record<string, string> = {
      rain: "https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?auto=format&fit=crop&w=1200&q=80",
      waves: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
      forest: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=80",
      fireplace: "https://images.unsplash.com/photo-1542296332-2e4473faf563?auto=format&fit=crop&w=1200&q=80",
      wind: "https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=1200&q=80",
      chill: "https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?auto=format&fit=crop&w=1200&q=80",
    };
    return images[type] || images.rain;
  }

  // Fallback generator for smart scene creation when offline/testing
  function generateSmartFallbackScene(prompt: string) {
    const lower = prompt.toLowerCase();
    if (lower.includes("playa") || lower.includes("atardecer") || lower.includes("mar") || lower.includes("sol")) {
      return {
        title: "Atardecer en la Playa",
        description: "Ambiente cálido y marinero que combina brisa templada, oleaje rítmico, aroma a sal marina y tonos dorados.",
        audioType: "waves",
        audioTrackName: "Olas suaves en la orilla + brisa marina",
        volume: 50,
        temperature: 24,
        humidity: 60,
        ventilation: "Brisa marina suave",
        fragrance: "Flor de naranjo, sal marina y bergamota",
        intensity: 65,
        lightColorName: "Ámbar atardecer",
        brightness: 45,
        lightColorTemp: "Cálido",
        imageUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
      };
    } else if (lower.includes("bosque") || lower.includes("amanecer") || lower.includes("pino") || lower.includes("verde")) {
      return {
        title: "Bosque al Amanecer con Niebla",
        description: "Atmósfera limpia e inspiradora con murmullo de hojas, bruma matutina, notas de musgo fresco y luz natural tenue.",
        audioType: "forest",
        audioTrackName: "Canto de aves silvestres + viento en las copas",
        volume: 35,
        temperature: 20,
        humidity: 75,
        ventilation: "Brisa fresca de montaña",
        fragrance: "Eucalipto, musgo húmedo y corteza de pino",
        intensity: 80,
        lightColorName: "Verde esmeralda ténue",
        brightness: 35,
        lightColorTemp: "Templado",
        imageUrl: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=80",
      };
    } else if (lower.includes("noche") || lower.includes("fuego") || lower.includes("chimenea") || lower.includes("invierno")) {
      return {
        title: "Noche de Invierno frente a la Chimenea",
        description: "Sensación acogedora e íntima con crujido de leña, calidez reconfortante, aroma ahumado de cedro y luz ámbar suave.",
        audioType: "fireplace",
        audioTrackName: "Crujido de leña + viento invernal tenue",
        volume: 45,
        temperature: 23,
        humidity: 50,
        ventilation: "Calefacción tenue de radiadores",
        fragrance: "Madera de cedro, vainilla ahumada y canela",
        intensity: 75,
        lightColorName: "Fuego tenue 2200K",
        brightness: 25,
        lightColorTemp: "Cálido",
        imageUrl: "https://images.unsplash.com/photo-1542296332-2e4473faf563?auto=format&fit=crop&w=1200&q=80",
      };
    }

    return {
      title: prompt.length > 25 ? prompt.slice(0, 25) + "..." : prompt,
      description: `Ambiente personalizado creado a partir de "${prompt}", diseñado para estimular tus sentidos y brindar máximo confort.`,
      audioType: "rain",
      audioTrackName: "Sonidos ambientales binaurales + lluvia ligera",
      volume: 40,
      temperature: 22,
      humidity: 65,
      ventilation: "Ventilación constante y silenciosa",
      fragrance: "Petricor, lavanda silvestre y ozono",
      intensity: 70,
      lightColorName: "Gris azulado equilibrado",
      brightness: 30,
      lightColorTemp: "Frío",
      imageUrl: "https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?auto=format&fit=crop&w=1200&q=80",
    };
  }

  // Vite Middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[AAURA] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
