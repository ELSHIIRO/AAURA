import React, { useState } from "react";

export const SettingsView: React.FC = () => {
  const [bridges, setBridges] = useState({
    sonos: true,
    nest: true,
    pura: true,
    hue: true,
  });

  const [aiAutoSync, setAiAutoSync] = useState(true);
  const [highQualityAudio, setHighQualityAudio] = useState(true);

  return (
    <div className="flex flex-col gap-8 max-w-4xl mx-auto px-4 md:px-8 py-6 pb-32 text-left">
      <div>
        <h2 className="text-2xl font-bold text-[#181c1c]">Ajustes del Sistema</h2>
        <p className="text-xs text-[#3e4949]">
          Configura tus integraciones de hardware, síntesis de audio y motor de Inteligencia Artificial.
        </p>
      </div>

      {/* Integraciones de Hardware */}
      <section className="glass-card rounded-3xl p-6 border border-white/60 flex flex-col gap-4 shadow-xs">
        <h3 className="font-bold text-base text-[#181c1c] flex items-center gap-2">
          <span className="material-symbols-outlined text-[#00666b]">hub</span>
          Integraciones & Puentes de Hardware
        </h3>

        <div className="flex flex-col gap-3">
          {[
            {
              id: "sonos",
              name: "Puente Sonos Sound System",
              desc: "Streaming de audio multizona de ultra baja latencia",
              key: "sonos" as const,
            },
            {
              id: "nest",
              name: "Google Nest Climate API",
              desc: "Control de climatización radiante y ventilación inteligente",
              key: "nest" as const,
            },
            {
              id: "pura",
              name: "Pura Smart Fragrance Bridge",
              desc: "Difusión de aceites esenciales y cartuchos aromatizadores",
              key: "pura" as const,
            },
            {
              id: "hue",
              name: "Philips Hue Bridge v2",
              desc: "Sincronización de luces cromáticas y temperatura de color",
              key: "hue" as const,
            },
          ].map((item) => (
            <div
              key={item.id}
              className="glass-panel p-4 rounded-2xl flex items-center justify-between border border-white/50"
            >
              <div>
                <h4 className="font-bold text-sm text-[#181c1c]">{item.name}</h4>
                <p className="text-xs text-[#3e4949]">{item.desc}</p>
              </div>
              <button
                onClick={() =>
                  setBridges((prev) => ({
                    ...prev,
                    [item.key]: !prev[item.key],
                  }))
                }
                className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                  bridges[item.key] ? "bg-[#00666b]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    bridges[item.key] ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Motor de Inteligencia Artificial */}
      <section className="glass-card rounded-3xl p-6 border border-white/60 flex flex-col gap-4 shadow-xs">
        <h3 className="font-bold text-base text-[#181c1c] flex items-center gap-2">
          <span className="material-symbols-outlined text-[#00666b]">
            auto_awesome
          </span>
          Configuración del Motor AAURA AI
        </h3>

        <div className="flex flex-col gap-3">
          <div className="glass-panel p-4 rounded-2xl flex items-center justify-between border border-white/50">
            <div>
              <h4 className="font-bold text-sm text-[#181c1c]">
                Síntesis Generativa Automática
              </h4>
              <p className="text-xs text-[#3e4949]">
                Permite a Gemini 3.6-Flash ajustar automáticamente clima e iluminación.
              </p>
            </div>
            <button
              onClick={() => setAiAutoSync(!aiAutoSync)}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                aiAutoSync ? "bg-[#00666b]" : "bg-gray-300"
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                  aiAutoSync ? "translate-x-5" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          <div className="glass-panel p-4 rounded-2xl flex items-center justify-between border border-white/50">
            <div>
              <h4 className="font-bold text-sm text-[#181c1c]">
                Audio Espacial WebAudio 32-bit
              </h4>
              <p className="text-xs text-[#3e4949]">
                Genera frecuencias de sonido ambiental en alta fidelidad.
              </p>
            </div>
            <button
              onClick={() => setHighQualityAudio(!highQualityAudio)}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                highQualityAudio ? "bg-[#00666b]" : "bg-gray-300"
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                  highQualityAudio ? "translate-x-5" : "translate-x-0"
                }`}
              />
            </button>
          </div>
        </div>
      </section>

      {/* Información del Sistema */}
      <div className="text-center text-xs text-[#3e4949] pt-4">
        <p className="font-bold text-[#00666b]">AAURA Smart Home v2.4.0</p>
        <p>Servidor Cloud Run • Node.js Full-Stack + Express + Gemini AI</p>
      </div>
    </div>
  );
};
