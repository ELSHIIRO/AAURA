import React from "react";
import { Scene, NavTab, AudioPlayerState } from "../../types";

interface HomeViewProps {
  scenes: Scene[];
  activeScene: Scene;
  playerState: AudioPlayerState;
  onActivateScene: (scene: Scene) => void;
  onNavigateTab: (tab: NavTab) => void;
  onOpenSceneDetails: (scene: Scene) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  scenes,
  activeScene,
  playerState,
  onActivateScene,
  onNavigateTab,
  onOpenSceneDetails,
}) => {
  return (
    <div className="flex flex-col gap-8 pb-32 max-w-6xl mx-auto px-4 md:px-8 py-6">
      {/* Hero Section: Escena Actual */}
      <section className="animate-[fadeIn_0.4s_ease-out]">
        <div className="relative w-full h-[320px] md:h-[380px] rounded-3xl overflow-hidden group cursor-pointer shadow-md border border-white/30">
          {/* Background Image */}
          <div
            className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
            style={{ backgroundImage: `url('${activeScene.imageUrl}')` }}
          />
          {/* Gradient Overlay for Readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#181c1c]/85 via-[#181c1c]/30 to-transparent" />

          {/* Content overlay */}
          <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-end text-white">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase tracking-widest text-white/80 font-bold bg-white/20 backdrop-blur-md px-3 py-1 rounded-full border border-white/30">
                Escena Actual
              </span>
              {playerState.isPlaying && (
                <span className="flex items-center gap-1 text-xs text-[#a0f0f5] font-bold bg-[#00666b]/80 px-2.5 py-0.5 rounded-full">
                  <span className="w-2 h-2 rounded-full bg-[#84d3d8] animate-ping" />
                  Sonido Activo
                </span>
              )}
            </div>
            <h3 className="text-2xl md:text-4xl font-bold text-white mb-2 tracking-tight">
              {activeScene.title}
            </h3>
            <p className="text-sm md:text-base text-white/90 max-w-xl mb-6 line-clamp-2 leading-relaxed">
              {activeScene.description}
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onActivateScene(activeScene)}
                className="flex items-center gap-2 bg-[#00666b] hover:bg-[#2b8085] text-white px-5 py-2.5 rounded-full font-bold text-sm shadow-lg transition-all duration-300 cursor-pointer"
              >
                <span className="material-symbols-outlined text-lg symbol-filled">
                  {playerState.isPlaying && playerState.sceneId === activeScene.id
                    ? "volume_up"
                    : "play_arrow"}
                </span>
                {playerState.isPlaying && playerState.sceneId === activeScene.id
                  ? "Reproduciendo"
                  : "Activar Escena"}
              </button>
              <button
                onClick={() => onOpenSceneDetails(activeScene)}
                className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/40 text-white px-5 py-2.5 rounded-full font-medium text-sm transition-all duration-300 cursor-pointer"
              >
                Ver detalles
                <span className="material-symbols-outlined text-sm">
                  arrow_forward
                </span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Escenas Rápidas */}
      <section>
        <div className="flex justify-between items-end mb-4">
          <div>
            <h3 className="text-xl md:text-2xl font-bold text-[#181c1c]">
              Escenas rápidas
            </h3>
            <p className="text-xs text-[#3e4949]">
              Cambia instantáneamente el ambiente de tu hogar con un clic.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab("escenas")}
            className="text-sm font-bold text-[#00666b] hover:underline cursor-pointer flex items-center gap-1"
          >
            Ver todas
            <span className="material-symbols-outlined text-base">
              chevron_right
            </span>
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {scenes.map((scene) => {
            const isActive = activeScene.id === scene.id;
            const iconsMap: Record<string, string> = {
              "Día Lluvioso": "rainy",
              "Atardecer en la Playa": "wb_sunny",
              "Bosque al Amanecer": "nature",
              "Noche de Invierno": "bedtime",
            };
            const iconName = iconsMap[scene.title] || "auto_awesome";

            return (
              <div
                key={scene.id}
                onClick={() => onActivateScene(scene)}
                className={`relative h-40 md:h-48 rounded-2xl overflow-hidden group cursor-pointer border transition-all duration-300 shadow-xs hover:shadow-md ${
                  isActive
                    ? "ring-2 ring-[#00666b] border-[#00666b]"
                    : "border-white/40 hover:scale-[1.02]"
                }`}
              >
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                  style={{ backgroundImage: `url('${scene.imageUrl}')` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#181c1c]/90 via-[#181c1c]/40 to-transparent flex flex-col items-center justify-center p-4 text-center">
                  <span
                    className={`material-symbols-outlined text-3xl mb-2 text-white ${
                      isActive ? "symbol-filled text-[#84d3d8]" : ""
                    }`}
                  >
                    {iconName}
                  </span>
                  <span className="font-bold text-sm text-white line-clamp-2">
                    {scene.title}
                  </span>
                  {isActive && (
                    <span className="mt-1 text-[10px] bg-[#00666b] text-white font-bold px-2 py-0.5 rounded-full">
                      Activa
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Dispositivos Quick Status */}
      <section>
        <div className="flex justify-between items-end mb-4">
          <div>
            <h3 className="text-xl md:text-2xl font-bold text-[#181c1c]">
              Dispositivos
            </h3>
            <p className="text-xs text-[#3e4949]">
              Estado actual de tus sistemas sensoriales conectados.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab("dispositivos")}
            className="text-sm font-bold text-[#00666b] hover:underline cursor-pointer flex items-center gap-1"
          >
            Ajustar
            <span className="material-symbols-outlined text-base">
              chevron_right
            </span>
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {/* Audio */}
          <div
            onClick={() => onNavigateTab("dispositivos")}
            className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center text-center gap-2 hover:shadow-md transition-all cursor-pointer border border-white/60 hover:scale-[1.02]"
          >
            <div className="w-12 h-12 rounded-full bg-[#00666b]/15 flex items-center justify-center text-[#00666b]">
              <span className="material-symbols-outlined text-2xl">
                volume_up
              </span>
            </div>
            <h4 className="font-bold text-base text-[#181c1c]">Audio</h4>
            <span className="text-xs text-[#00666b] font-bold">
              Sonos • {activeScene.audio.volume}%
            </span>
          </div>

          {/* Clima */}
          <div
            onClick={() => onNavigateTab("dispositivos")}
            className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center text-center gap-2 hover:shadow-md transition-all cursor-pointer border border-white/60 hover:scale-[1.02]"
          >
            <div className="w-12 h-12 rounded-full bg-[#e67e22]/15 flex items-center justify-center text-[#e67e22]">
              <span className="material-symbols-outlined text-2xl">
                thermostat
              </span>
            </div>
            <h4 className="font-bold text-base text-[#181c1c]">Clima</h4>
            <span className="text-xs text-[#e67e22] font-bold">
              Nest • {activeScene.climate.temperature}°C
            </span>
          </div>

          {/* Aroma */}
          <div
            onClick={() => onNavigateTab("dispositivos")}
            className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center text-center gap-2 hover:shadow-md transition-all cursor-pointer border border-white/60 hover:scale-[1.02]"
          >
            <div className="w-12 h-12 rounded-full bg-[#9b59b6]/15 flex items-center justify-center text-[#9b59b6]">
              <span className="material-symbols-outlined text-2xl">air</span>
            </div>
            <h4 className="font-bold text-base text-[#181c1c]">Aroma</h4>
            <span className="text-xs text-[#9b59b6] font-bold">
              Pura • {activeScene.aroma.intensity}%
            </span>
          </div>

          {/* Iluminación */}
          <div
            onClick={() => onNavigateTab("dispositivos")}
            className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center text-center gap-2 hover:shadow-md transition-all cursor-pointer border border-white/60 hover:scale-[1.02]"
          >
            <div className="w-12 h-12 rounded-full bg-[#f1c40f]/15 flex items-center justify-center text-[#f1c40f]">
              <span className="material-symbols-outlined text-2xl symbol-filled">
                lightbulb
              </span>
            </div>
            <h4 className="font-bold text-base text-[#181c1c]">Iluminación</h4>
            <span className="text-xs text-[#d4ac0d] font-bold">
              Hue • {activeScene.lighting.brightness}%
            </span>
          </div>
        </div>
      </section>
    </div>
  );
};
