import React, { useState } from "react";
import {
  SonosDevice,
  NestThermostatDevice,
  PuraDiffuserDevice,
  HueLightingDevice,
  SmartDeviceItem,
} from "../../types";

interface DevicesViewProps {
  sonos: SonosDevice;
  nest: NestThermostatDevice;
  pura: PuraDiffuserDevice;
  hue: HueLightingDevice;
  customDevices: SmartDeviceItem[];
  onUpdateSonos: (updated: Partial<SonosDevice>) => void;
  onUpdateNest: (updated: Partial<NestThermostatDevice>) => void;
  onUpdatePura: (updated: Partial<PuraDiffuserDevice>) => void;
  onUpdateHue: (updated: Partial<HueLightingDevice>) => void;
  onToggleCustomDevice: (id: string) => void;
  onOpenAddModal: () => void;
}

export const DevicesView: React.FC<DevicesViewProps> = ({
  sonos,
  nest,
  pura,
  hue,
  customDevices,
  onUpdateSonos,
  onUpdateNest,
  onUpdatePura,
  onUpdateHue,
  onToggleCustomDevice,
  onOpenAddModal,
}) => {
  const [deviceFilter, setDeviceFilter] = useState("Todos");

  return (
    <div className="flex flex-col gap-8 max-w-6xl mx-auto px-4 md:px-8 py-6 pb-32">
      {/* Category Filters */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-2 border-b border-white/40">
        <div className="flex items-center gap-2">
          {["Todos", "Audio", "Clima", "Aroma", "Iluminación", "Confort"].map(
            (cat) => (
              <button
                key={cat}
                onClick={() => setDeviceFilter(cat)}
                className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  deviceFilter === cat
                    ? "bg-[#00666b] text-white shadow-xs"
                    : "glass-panel text-[#3e4949] hover:bg-white/80"
                }`}
              >
                {cat}
              </button>
            )
          )}
        </div>
        <button
          onClick={onOpenAddModal}
          className="flex items-center gap-1.5 bg-[#00666b] text-white px-4 py-2 rounded-full text-xs font-bold shadow-xs hover:bg-[#2b8085] transition-colors shrink-0 cursor-pointer"
        >
          <span className="material-symbols-outlined text-base">add</span>
          Vincular Dispositivo
        </button>
      </div>

      {/* Core Sensory Devices Grid (Matching Image 2) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 1. Sonos Era 300 (Audio) */}
        {(deviceFilter === "Todos" || deviceFilter === "Audio") && (
          <div className="glass-card rounded-3xl p-6 flex flex-col gap-5 border border-white/60 shadow-sm">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#00666b]/15 flex items-center justify-center text-[#00666b]">
                  <span className="material-symbols-outlined text-2xl">
                    volume_up
                  </span>
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-lg text-[#181c1c]">
                    Sonos Era 300
                  </h3>
                  <span className="text-xs text-[#3e4949] font-medium">
                    Audio Sensorial • Sala de Estar
                  </span>
                </div>
              </div>
              <button
                onClick={() =>
                  onUpdateSonos({ isPoweredOn: !sonos.isPoweredOn })
                }
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  sonos.isPoweredOn ? "bg-[#00666b]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    sonos.isPoweredOn ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            {sonos.isPoweredOn ? (
              <div className="flex flex-col gap-4 text-left">
                <div className="glass-panel p-3.5 rounded-xl border border-white/50 flex items-center gap-3">
                  <span className="material-symbols-outlined text-2xl text-[#00666b] symbol-filled">
                    graphic_eq
                  </span>
                  <div className="overflow-hidden">
                    <span className="text-[10px] uppercase font-bold text-[#00666b]">
                      Pista Actual
                    </span>
                    <p className="text-xs font-bold text-[#181c1c] truncate">
                      {sonos.currentTrack}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <div className="flex justify-between text-xs font-semibold text-[#181c1c]">
                    <span>Volumen</span>
                    <span>{sonos.volume}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={sonos.volume}
                    onChange={(e) =>
                      onUpdateSonos({ volume: Number(e.target.value) })
                    }
                    className="w-full h-2 bg-[#bec9c9]/50 rounded-lg appearance-none cursor-pointer accent-[#00666b]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="bg-white/50 p-2.5 rounded-xl text-center">
                    <span className="text-[10px] text-[#3e4949] font-bold block">
                      Graves (Bass)
                    </span>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <button
                        onClick={() =>
                          onUpdateSonos({ bass: Math.max(-5, sonos.bass - 1) })
                        }
                        className="w-6 h-6 rounded-full bg-white text-xs font-bold shadow-xs cursor-pointer"
                      >
                        -
                      </button>
                      <span className="text-xs font-bold">{sonos.bass}</span>
                      <button
                        onClick={() =>
                          onUpdateSonos({ bass: Math.min(5, sonos.bass + 1) })
                        }
                        className="w-6 h-6 rounded-full bg-white text-xs font-bold shadow-xs cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <div className="bg-white/50 p-2.5 rounded-xl text-center">
                    <span className="text-[10px] text-[#3e4949] font-bold block">
                      Agudos (Treble)
                    </span>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <button
                        onClick={() =>
                          onUpdateSonos({
                            treble: Math.max(-5, sonos.treble - 1),
                          })
                        }
                        className="w-6 h-6 rounded-full bg-white text-xs font-bold shadow-xs cursor-pointer"
                      >
                        -
                      </button>
                      <span className="text-xs font-bold">{sonos.treble}</span>
                      <button
                        onClick={() =>
                          onUpdateSonos({
                            treble: Math.min(5, sonos.treble + 1),
                          })
                        }
                        className="w-6 h-6 rounded-full bg-white text-xs font-bold shadow-xs cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#3e4949] italic py-4">
                El sistema de audio está apagado.
              </p>
            )}
          </div>
        )}

        {/* 2. Nest Thermostat (Clima) */}
        {(deviceFilter === "Todos" || deviceFilter === "Clima") && (
          <div className="glass-card rounded-3xl p-6 flex flex-col gap-5 border border-white/60 shadow-sm">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#e67e22]/15 flex items-center justify-center text-[#e67e22]">
                  <span className="material-symbols-outlined text-2xl">
                    thermostat
                  </span>
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-lg text-[#181c1c]">
                    Nest Thermostat
                  </h3>
                  <span className="text-xs text-[#3e4949] font-medium">
                    Clima Sensorial • Toda la Casa
                  </span>
                </div>
              </div>
              <button
                onClick={() =>
                  onUpdateNest({ isPoweredOn: !nest.isPoweredOn })
                }
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  nest.isPoweredOn ? "bg-[#e67e22]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    nest.isPoweredOn ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            {nest.isPoweredOn ? (
              <div className="flex flex-col gap-4 text-left">
                {/* Radial Thermostat Display */}
                <div className="flex items-center justify-around bg-white/40 p-4 rounded-2xl border border-white/50">
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] uppercase font-bold text-[#3e4949]">
                      Interior
                    </span>
                    <span className="text-xl font-bold text-[#181c1c]">
                      {nest.indoorTemp}°C
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() =>
                        onUpdateNest({
                          targetTemp: Math.max(16, nest.targetTemp - 1),
                        })
                      }
                      className="w-9 h-9 rounded-full bg-white text-[#e67e22] text-xl font-bold shadow-xs hover:scale-105 transition-transform cursor-pointer"
                    >
                      -
                    </button>
                    <div className="flex flex-col items-center">
                      <span className="text-3xl font-extrabold text-[#e67e22]">
                        {nest.targetTemp}°C
                      </span>
                      <span className="text-[10px] text-[#3e4949] font-bold">
                        Objetivo
                      </span>
                    </div>
                    <button
                      onClick={() =>
                        onUpdateNest({
                          targetTemp: Math.min(30, nest.targetTemp + 1),
                        })
                      }
                      className="w-9 h-9 rounded-full bg-white text-[#e67e22] text-xl font-bold shadow-xs hover:scale-105 transition-transform cursor-pointer"
                    >
                      +
                    </button>
                  </div>

                  <div className="flex flex-col items-center">
                    <span className="text-[10px] uppercase font-bold text-[#3e4949]">
                      Humedad
                    </span>
                    <span className="text-xl font-bold text-[#181c1c]">
                      {nest.humidity}%
                    </span>
                  </div>
                </div>

                {/* Modes */}
                <div className="flex items-center justify-between gap-1 pt-1">
                  {(["Eco", "Frío", "Calor", "Auto"] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => onUpdateNest({ mode })}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        nest.mode === mode
                          ? "bg-[#e67e22] text-white shadow-xs"
                          : "bg-white/60 text-[#3e4949] hover:bg-white/90"
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#3e4949] italic py-4">
                El climatizador Nest está desactivado.
              </p>
            )}
          </div>
        )}

        {/* 3. Pura Diffuser (Aroma) */}
        {(deviceFilter === "Todos" || deviceFilter === "Aroma") && (
          <div className="glass-card rounded-3xl p-6 flex flex-col gap-5 border border-white/60 shadow-sm">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#9b59b6]/15 flex items-center justify-center text-[#9b59b6]">
                  <span className="material-symbols-outlined text-2xl">air</span>
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-lg text-[#181c1c]">
                    Pura Diffuser
                  </h3>
                  <span className="text-xs text-[#3e4949] font-medium">
                    Difusor de Aroma • Sala
                  </span>
                </div>
              </div>
              <button
                onClick={() =>
                  onUpdatePura({ isPoweredOn: !pura.isPoweredOn })
                }
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  pura.isPoweredOn ? "bg-[#9b59b6]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    pura.isPoweredOn ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            {pura.isPoweredOn ? (
              <div className="flex flex-col gap-4 text-left">
                <div>
                  <label className="block text-xs font-bold uppercase text-[#3e4949] mb-1">
                    Fragancia Activa
                  </label>
                  <select
                    value={pura.currentFragrance}
                    onChange={(e) =>
                      onUpdatePura({ currentFragrance: e.target.value })
                    }
                    className="w-full glass-panel rounded-xl p-3 text-xs font-bold text-[#181c1c] border border-white/60 focus:outline-none"
                  >
                    {pura.availableFragrances.map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col gap-2">
                  <div className="flex justify-between text-xs font-semibold text-[#181c1c]">
                    <span>Intensidad de Difusión</span>
                    <span>{pura.intensity}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={pura.intensity}
                    onChange={(e) =>
                      onUpdatePura({ intensity: Number(e.target.value) })
                    }
                    className="w-full h-2 bg-[#bec9c9]/50 rounded-lg appearance-none cursor-pointer accent-[#9b59b6]"
                  />
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#3e4949] italic py-4">
                El difusor Pura está apagado.
              </p>
            )}
          </div>
        )}

        {/* 4. Philips Hue (Iluminación) */}
        {(deviceFilter === "Todos" || deviceFilter === "Iluminación") && (
          <div className="glass-card rounded-3xl p-6 flex flex-col gap-5 border border-white/60 shadow-sm">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#f1c40f]/15 flex items-center justify-center text-[#f1c40f]">
                  <span className="material-symbols-outlined text-2xl symbol-filled">
                    lightbulb
                  </span>
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-lg text-[#181c1c]">
                    Philips Hue
                  </h3>
                  <span className="text-xs text-[#3e4949] font-medium">
                    Iluminación Dinámica
                  </span>
                </div>
              </div>
              <button
                onClick={() => onUpdateHue({ isPoweredOn: !hue.isPoweredOn })}
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  hue.isPoweredOn ? "bg-[#d4ac0d]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    hue.isPoweredOn ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            {hue.isPoweredOn ? (
              <div className="flex flex-col gap-4 text-left">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl shadow-xs border border-white/60 shrink-0"
                    style={{ backgroundColor: hue.colorHex }}
                  />
                  <div className="flex-1">
                    <span className="text-[10px] uppercase font-bold text-[#3e4949]">
                      Tono Actual
                    </span>
                    <p className="text-xs font-bold text-[#181c1c]">
                      {hue.colorName}
                    </p>
                  </div>
                  <div className="flex gap-1.5">
                    {[
                      { name: "Gris azulado", hex: "#5A7184" },
                      { name: "Ámbar atardecer", hex: "#E67E22" },
                      { name: "Verde esmeralda", hex: "#2ECC71" },
                      { name: "Rojo tenue", hex: "#E74C3C" },
                    ].map((c) => (
                      <button
                        key={c.hex}
                        onClick={() =>
                          onUpdateHue({ colorName: c.name, colorHex: c.hex })
                        }
                        className="w-6 h-6 rounded-full border border-white shadow-xs cursor-pointer hover:scale-110 transition-transform"
                        style={{ backgroundColor: c.hex }}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <div className="flex justify-between text-xs font-semibold text-[#181c1c]">
                    <span>Brillo</span>
                    <span>{hue.brightness}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={hue.brightness}
                    onChange={(e) =>
                      onUpdateHue({ brightness: Number(e.target.value) })
                    }
                    className="w-full h-2 bg-[#bec9c9]/50 rounded-lg appearance-none cursor-pointer accent-[#f1c40f]"
                  />
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#3e4949] italic py-4">
                Las luces Philips Hue están apagadas.
              </p>
            )}
          </div>
        )}
      </div>

      {/* Additional Connected Hardware */}
      <section className="text-left">
        <h3 className="font-bold text-lg text-[#181c1c] mb-4">
          Otros Dispositivos Conectados
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {customDevices.map((dev) => (
            <div
              key={dev.id}
              className="glass-card rounded-2xl p-4 flex items-center justify-between border border-white/50"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/60 flex items-center justify-center text-[#00666b]">
                  <span className="material-symbols-outlined">{dev.icon}</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#181c1c]">
                    {dev.name}
                  </h4>
                  <span className="text-xs text-[#3e4949]">
                    {dev.location} • {dev.status}
                  </span>
                </div>
              </div>
              <button
                onClick={() => onToggleCustomDevice(dev.id)}
                className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                  dev.isPoweredOn ? "bg-[#00666b]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    dev.isPoweredOn ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
