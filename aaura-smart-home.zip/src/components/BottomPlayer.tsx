import React, { useState } from "react";
import { AudioPlayerState } from "../types";

interface BottomPlayerProps {
  playerState: AudioPlayerState;
  onTogglePlay: () => void;
  onVolumeChange: (newVol: number) => void;
}

export const BottomPlayer: React.FC<BottomPlayerProps> = ({
  playerState,
  onTogglePlay,
  onVolumeChange,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  if (!playerState.sceneTitle) return null;

  return (
    <>
      {/* Floating Ambient Bar */}
      <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 w-[92%] md:w-auto md:min-w-[480px] max-w-2xl bg-[#e6e9e8]/90 backdrop-blur-3xl rounded-full border border-white/50 shadow-2xl z-40 p-2 pr-6 flex items-center justify-between gap-4 transition-all duration-300">
        <div
          onClick={() => setIsExpanded(true)}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="relative">
            <img
              src={playerState.imageUrl}
              alt={playerState.sceneTitle}
              className="w-12 h-12 rounded-full object-cover shadow-xs border border-white/60 group-hover:scale-105 transition-transform"
            />
            {playerState.isPlaying && (
              <span className="absolute -bottom-0.5 -right-0.5 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00666b] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-[#00666b]"></span>
              </span>
            )}
          </div>
          <div className="flex flex-col text-left">
            <span className="text-[10px] uppercase tracking-wider text-[#3e4949] font-bold">
              En reproducción
            </span>
            <span className="text-sm font-bold text-[#181c1c] truncate max-w-[180px] sm:max-w-[240px]">
              {playerState.sceneTitle}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Play/Pause Button */}
          <button
            onClick={onTogglePlay}
            className="w-10 h-10 rounded-full bg-[#00666b] text-white flex items-center justify-center hover:scale-110 active:scale-95 transition-transform shadow-md cursor-pointer"
            title={playerState.isPlaying ? "Pausar" : "Reproducir"}
          >
            <span className="material-symbols-outlined text-2xl symbol-filled">
              {playerState.isPlaying ? "pause" : "play_arrow"}
            </span>
          </button>

          {/* Volume Slider Mockup */}
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => onVolumeChange(playerState.volume === 0 ? 50 : 0)}
              className="text-[#3e4949] hover:text-[#00666b] transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-lg">
                {playerState.volume === 0 ? "volume_off" : "volume_up"}
              </span>
            </button>
            <div className="w-24 relative flex items-center">
              <input
                type="range"
                min="0"
                max="100"
                value={playerState.volume}
                onChange={(e) => onVolumeChange(Number(e.target.value))}
                className="w-full h-1.5 bg-[#bec9c9]/50 rounded-lg appearance-none cursor-pointer accent-[#00666b]"
              />
            </div>
            <span className="text-xs font-semibold text-[#3e4949] w-7 text-right">
              {playerState.volume}%
            </span>
          </div>

          {/* Expand Button */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-[#3e4949] hover:text-[#00666b] transition-colors p-1 rounded-full cursor-pointer"
            title="Detalles de audio"
          >
            <span className="material-symbols-outlined text-2xl">
              {isExpanded ? "expand_more" : "expand_less"}
            </span>
          </button>
        </div>
      </div>

      {/* Expanded Equalizer & Soundscape Modal */}
      {isExpanded && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="glass-card rounded-3xl p-6 md:p-8 max-w-md w-full flex flex-col gap-6 shadow-2xl relative border border-white/60 animate-[fadeIn_0.2s_ease-out]">
            <button
              onClick={() => setIsExpanded(false)}
              className="absolute top-4 right-4 p-2 text-[#3e4949] hover:bg-black/5 rounded-full transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-2xl">close</span>
            </button>

            <div className="flex flex-col items-center text-center gap-3 pt-2">
              <div className="w-28 h-28 rounded-2xl overflow-hidden shadow-md border border-white/80 relative">
                <img
                  src={playerState.imageUrl}
                  alt={playerState.sceneTitle}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="text-xs uppercase font-bold text-[#00666b] tracking-wider">
                  Ecualizador de Ambiente AAURA
                </span>
                <h3 className="text-xl font-bold text-[#181c1c]">
                  {playerState.sceneTitle}
                </h3>
                <p className="text-xs text-[#3e4949] mt-1">
                  {playerState.trackName}
                </p>
              </div>
            </div>

            {/* Visual Equalizer Bars */}
            <div className="flex items-center justify-center gap-2 h-16 bg-white/40 rounded-2xl p-4 border border-white/40">
              {[40, 75, 55, 90, 30, 80, 60, 45, 95, 50, 70, 35].map(
                (height, idx) => (
                  <div
                    key={idx}
                    className={`w-1.5 bg-[#00666b] rounded-full transition-all duration-300 ${
                      playerState.isPlaying ? "animate-pulse" : "opacity-40"
                    }`}
                    style={{
                      height: playerState.isPlaying
                        ? `${Math.max(15, (height * (playerState.volume / 100)))}%`
                        : "20%",
                      animationDelay: `${idx * 0.1}s`,
                    }}
                  />
                )
              )}
            </div>

            {/* Volume & Equalizer Sliders */}
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-[#181c1c]">
                  Volumen Maestro
                </span>
                <span className="text-sm font-bold text-[#00666b]">
                  {playerState.volume}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={playerState.volume}
                onChange={(e) => onVolumeChange(Number(e.target.value))}
                className="w-full h-2 bg-[#bec9c9]/50 rounded-lg appearance-none cursor-pointer accent-[#00666b]"
              />
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-white/30">
              <button
                onClick={onTogglePlay}
                className="w-full py-3 bg-[#00666b] text-white rounded-xl font-bold hover:bg-[#2b8085] transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span className="material-symbols-outlined symbol-filled">
                  {playerState.isPlaying ? "pause" : "play_arrow"}
                </span>
                {playerState.isPlaying ? "Pausar Sonido" : "Reanudar Sonido"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
