import React from "react";
import { HistoryLog } from "../../types";

interface HistoryViewProps {
  logs: HistoryLog[];
  onClearLogs: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ logs, onClearLogs }) => {
  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto px-4 md:px-8 py-6 pb-32 text-left">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#181c1c]">
            Historial de Actividad Sensorial
          </h2>
          <p className="text-xs text-[#3e4949]">
            Registro de eventos, ejecuciones de IA y cambios de escenas en tu hogar.
          </p>
        </div>
        {logs.length > 0 && (
          <button
            onClick={onClearLogs}
            className="text-xs text-[#ba1a1a] font-bold hover:underline cursor-pointer"
          >
            Limpiar historial
          </button>
        )}
      </div>

      <div className="flex flex-col gap-3">
        {logs.length === 0 ? (
          <div className="glass-card rounded-3xl p-12 text-center text-[#3e4949]">
            <span className="material-symbols-outlined text-4xl mb-2 opacity-50">
              history
            </span>
            <p className="text-sm font-medium">El historial está vacío.</p>
          </div>
        ) : (
          logs.map((log) => (
            <div
              key={log.id}
              className="glass-card rounded-2xl p-4 flex items-start gap-4 border border-white/50 hover:bg-white/60 transition-colors"
            >
              <div className="w-10 h-10 rounded-xl bg-[#00666b]/15 flex items-center justify-center text-[#00666b] shrink-0 mt-0.5">
                <span className="material-symbols-outlined text-xl">
                  {log.icon}
                </span>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <h4 className="font-bold text-sm text-[#181c1c]">
                    {log.title}
                  </h4>
                  <span className="text-[10px] font-semibold text-[#3e4949] bg-white/60 px-2 py-0.5 rounded-full">
                    {log.timestamp}
                  </span>
                </div>
                <p className="text-xs text-[#3e4949] leading-relaxed">
                  {log.description}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
