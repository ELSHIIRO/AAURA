export type NavTab =
  | "inicio"
  | "escenas"
  | "dispositivos"
  | "rutinas"
  | "historial"
  | "ajustes"
  | "perfil";

export type ScenesSubView = "list" | "create_wizard" | "create_ai";

export type AudioSoundType =
  | "rain"
  | "waves"
  | "forest"
  | "fireplace"
  | "wind"
  | "ambient";

export interface AudioSettings {
  soundType: AudioSoundType;
  trackName: string;
  volume: number; // 0-100
}

export interface ClimateSettings {
  temperature: number; // °C
  humidity: number; // %
  ventilation: string;
}

export interface AromaSettings {
  fragrance: string;
  intensity: number; // 0-100
}

export interface LightingSettings {
  colorName: string;
  colorHex: string;
  brightness: number; // 0-100
  colorTemp: "Frío" | "Templado" | "Cálido";
}

export interface Scene {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  isFavorite: boolean;
  category: "Sensorial" | "Trabajo" | "Relajación" | "IA Generada" | "Noche";
  audio: AudioSettings;
  climate: ClimateSettings;
  aroma: AromaSettings;
  lighting: LightingSettings;
}

export interface SonosDevice {
  id: string;
  name: string;
  model: string;
  isPoweredOn: boolean;
  volume: number;
  currentTrack: string;
  bass: number;
  treble: number;
}

export interface NestThermostatDevice {
  id: string;
  name: string;
  model: string;
  isPoweredOn: boolean;
  targetTemp: number;
  indoorTemp: number;
  humidity: number;
  mode: "Frío" | "Calor" | "Eco" | "Auto";
}

export interface PuraDiffuserDevice {
  id: string;
  name: string;
  model: string;
  isPoweredOn: boolean;
  intensity: number;
  currentFragrance: string;
  availableFragrances: string[];
}

export interface HueLightingDevice {
  id: string;
  name: string;
  model: string;
  isPoweredOn: boolean;
  brightness: number;
  colorName: string;
  colorHex: string;
  colorTemp: "Frío" | "Templado" | "Cálido";
}

export interface SmartDeviceItem {
  id: string;
  name: string;
  category: "Audio" | "Clima" | "Aroma" | "Iluminación" | "Seguridad" | "Confort";
  status: string;
  isOnline: boolean;
  isPoweredOn: boolean;
  location: string;
  icon: string;
}

export interface Routine {
  id: string;
  title: string;
  description: string;
  schedule: string;
  icon: string;
  isActive: boolean;
  sceneId: string;
  days: string[];
}

export interface HistoryLog {
  id: string;
  timestamp: string;
  title: string;
  description: string;
  category: "escena" | "dispositivo" | "ia" | "rutina";
  icon: string;
}

export interface AudioPlayerState {
  isPlaying: boolean;
  sceneId: string | null;
  sceneTitle: string;
  trackName: string;
  volume: number;
  isMuted: boolean;
  imageUrl: string;
  audioType: AudioSoundType;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: "info" | "success" | "warning";
  read: boolean;
}
