import React, { useState } from "react";
import { SmartDeviceItem } from "../types";

interface AddDeviceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDevice: (device: SmartDeviceItem) => void;
}

export const AddDeviceModal: React.FC<AddDeviceModalProps> = ({
  isOpen,
  onClose,
  onAddDevice,
}) => {
  const [name, setName] = useState("");
  const [category, setCategory] = useState<SmartDeviceItem["category"]>("Confort");
  const [location, setLocation] = useState("Sala de Estar");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const iconsMap: Record<SmartDeviceItem["category"], string> = {
      Audio: "volume_up",
      Clima: "thermostat",
      Aroma: "air",
      Iluminación: "lightbulb",
      Seguridad: "videocam",
      Confort: "power",
    };

    const newDevice: SmartDeviceItem = {
      id: `dev-custom-${Date.now()}`,
      name: name.trim(),
      category,
      status: "Conectado • En espera",
      isOnline: true,
      isPoweredOn: true,
      location,
      icon: iconsMap[category] || "devices",
    };

    onAddDevice(newDevice);
    setName("");
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="glass-card rounded-3xl p-6 md:p-8 max-w-lg w-full flex flex-col gap-6 shadow-2xl relative border border-white/60 animate-[fadeIn_0.2s_ease-out]">
        <div className="flex justify-between items-center pb-2 border-b border-white/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#00666b] text-white flex items-center justify-center">
              <span className="material-symbols-outlined">add</span>
            </div>
            <h3 className="text-xl font-bold text-[#181c1c]">
              Vincular Dispositivo Inteligente
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#3e4949] hover:bg-black/5 rounded-full transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-2xl">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#3e4949] mb-1">
              Nombre del Dispositivo
            </label>
            <input
              type="text"
              required
              placeholder="Ej: Lámpara de Lectura, Humidificador"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full glass-panel rounded-xl py-3 px-4 text-sm text-[#181c1c] placeholder:text-[#3e4949]/50 focus:outline-none focus:ring-2 focus:ring-[#00666b]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#3e4949] mb-1">
                Categoría
              </label>
              <select
                value={category}
                onChange={(e) =>
                  setCategory(e.target.value as SmartDeviceItem["category"])
                }
                className="w-full glass-panel rounded-xl py-3 px-3 text-sm text-[#181c1c] focus:outline-none focus:ring-2 focus:ring-[#00666b]"
              >
                <option value="Audio">Audio</option>
                <option value="Clima">Clima</option>
                <option value="Aroma">Aroma</option>
                <option value="Iluminación">Iluminación</option>
                <option value="Seguridad">Seguridad</option>
                <option value="Confort">Confort</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#3e4949] mb-1">
                Ubicación en el Hogar
              </label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full glass-panel rounded-xl py-3 px-3 text-sm text-[#181c1c] focus:outline-none focus:ring-2 focus:ring-[#00666b]"
              >
                <option value="Sala de Estar">Sala de Estar</option>
                <option value="Habitación Principal">Habitación Principal</option>
                <option value="Estudio / Oficina">Estudio / Oficina</option>
                <option value="Cocina">Cocina</option>
                <option value="Jardín / Exterior">Jardín / Exterior</option>
              </select>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="w-1/2 py-3 glass-panel rounded-xl text-sm font-semibold text-[#00666b] hover:bg-white/60 transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="w-1/2 py-3 bg-[#00666b] text-white rounded-xl text-sm font-bold shadow-md hover:bg-[#2b8085] transition-colors cursor-pointer"
            >
              Vincular Dispositivo
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
